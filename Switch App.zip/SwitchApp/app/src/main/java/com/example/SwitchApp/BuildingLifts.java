package com.example.SwitchApp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import com.example.AdapterClasses.BuildingsAdapter;
import com.example.ModelClasses.ButtonModel;

import java.util.ArrayList;

public class BuildingLifts extends AppCompatActivity {

    ImageButton button;
    String db_username, db_userlevel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_building_lifts);


        Intent intent = getIntent();
        db_username = intent.getStringExtra("current_user");
        db_userlevel = intent.getStringExtra("level");


        ArrayList<ButtonModel> list = new ArrayList<>();

        ButtonModel buttonModel = new ButtonModel("PL 8",button);
        ButtonModel buttonModel1 = new ButtonModel("PL 7",button);
        ButtonModel buttonModel2 = new ButtonModel("PL 6",button);
        ButtonModel buttonModel3 = new ButtonModel("PL 5",button);
        ButtonModel buttonModel4 = new ButtonModel("PL 4",button);
        ButtonModel buttonModel5 = new ButtonModel("PL 3",button);

        list.add(buttonModel);
        list.add(buttonModel1);
        list.add(buttonModel2);
        list.add(buttonModel3);
        list.add(buttonModel4);
        list.add(buttonModel5);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        BuildingsAdapter adapter = new BuildingsAdapter(BuildingLifts.this,list,db_username);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }
}