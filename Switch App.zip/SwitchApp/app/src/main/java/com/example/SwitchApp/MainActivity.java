package com.example.SwitchApp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Notifications.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    ImageButton logout;
    SessionManager session;
    SwitchCompat switch1;
    String message;

    RelativeLayout rll;
    TextView connection_loss;

    String control_id, username, status,mannual_status, time,statusid;

    SwipeRefreshLayout swipe_container;

    String db_username,db_userlevel;

    public BroadcastReceiver mMessageReceiver1 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Get extra data included in the Intent
            message = intent.getStringExtra("message");

            getSignal("other");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(mMessageReceiver1,
                new IntentFilter(Config.PUSH_NOTIFICATION));
        init();

        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    updateButton(db_username, "On");
                } else {
                    updateButton(db_username, "Off");
                }


                switch1.setEnabled(false);
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        switch1.setEnabled(true);
                    }
                }, 1000);
            }
        });


        getSignal("first");
    }

    public void init() {

//        session = new SessionManager(getApplicationContext());
//        HashMap<String, String> user = session.getUserDetails();
//        key_username = user.get(SessionManager.KEY_NAME);

        Intent intent = getIntent();
        db_username = intent.getStringExtra("current_user");
        db_userlevel = intent.getStringExtra("level");


        switch1 = findViewById(R.id.switch1);
        rll = findViewById(R.id.rll);
        connection_loss = findViewById(R.id.connection_loss);

        logout = findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                session.logoutUser();
            }
        });
        swipe_container = findViewById(R.id.swipe_container);
        swipe_container.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                getSignal("first");



                //swipe_container.setRefreshing(false);
                // To keep animation for 4 seconds
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // Stop animation (This will be after 3 seconds)
                        swipe_container.setRefreshing(false);
                    }
                }, 3000); // Delay in millis
            }
        });

    }


    // Update Button...
    private void updateButton(final String username, final String status) {


        try {

            String HttpURL = "http://mitstiimm.com/Smart_Home/updateButton.php";


            StringRequest request = new StringRequest(Request.Method.POST, HttpURL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }

            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {


                    // DataBase entries....
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("username", username);
                    params.put("status", status);


                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
            requestQueue.add(request);


        } catch (Exception e) {
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        getSignal("first");
    }

    private void getSignal(String method) {

        final String url = "http://mitstiimm.com/Smart_Home/getSignal.php?method="+method;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        // Toast.makeText(Splash_Activity.this, ""+response, Toast.LENGTH_SHORT).show();



                        try {
                            JSONArray jsonArray = response.getJSONArray("data");

                            // Toast.makeText(Admin_Home.this, ""+response, Toast.LENGTH_SHORT).show();

                            for (int i = 0; i < jsonArray.length(); i++) {


                                JSONObject notifications = jsonArray.getJSONObject(i);



                                control_id = notifications.getString("control_id");
                                username = notifications.getString("username");
                                status = notifications.getString("status");
                                mannual_status = notifications.getString("mannual_status");
                                time = notifications.getString("time");
                                statusid = notifications.getString("statusid");

                            }


                            if (status.equals("On")){
                                switch1.setChecked(true);

                                //initials..
                                rll.setVisibility(View.VISIBLE);
                                connection_loss.setVisibility(View.GONE);
                            }else if (status.equals("Off")) {
                                switch1.setChecked(false);


                                //initials..
                                rll.setVisibility(View.VISIBLE);
                                connection_loss.setVisibility(View.GONE);
                            }

                            else if (status.isEmpty() || status == null){
                                rll.setVisibility(View.GONE);
                                connection_loss.setVisibility(View.VISIBLE);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            // stop animating Shimmer and hide the layout

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();
                // customToast(error.getMessage());

            }
        });


        // Creating RequestQueue.
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(request);

    }
}