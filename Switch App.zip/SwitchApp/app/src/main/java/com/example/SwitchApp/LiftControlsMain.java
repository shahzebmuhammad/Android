package com.example.SwitchApp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.AdapterClasses.ButtonAdapter;
import com.example.Notifications.Config;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LiftControlsMain extends AppCompatActivity {


    ImageButton button;
    String email, lift_name;
    RecyclerView recyclerView;
    ButtonAdapter adapter;
    TextView up_layout, up_icon, home, down_layout, down_icon, LED;
    String message, state;
    ImageButton btn;

    String id, username, lift_movement, time;

    Animation
            animFadeIn, animFadeOut, animBlink, animZoomIn, animZoomOut, animRotate, animMove, animSlideUp, animSlideDown, animBounce, animSequential, animTogether, animCrossFadeIn, animCrossFadeOut;


    RelativeLayout rll_8, rll_7, rll_1, rll_gf;
    TextView btn_text_8, btn_text_7, btn_text_1, btn_text_gf;

    ToggleButton toggleButton;


    public BroadcastReceiver mMessageReceiver1 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Get extra data included in the Intent
            message = intent.getStringExtra("message");

            getSignal(email, "other");
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lift_controls_main);

        init();


        LocalBroadcastManager.getInstance(getApplicationContext()).registerReceiver(mMessageReceiver1,
                new IntentFilter(Config.PUSH_NOTIFICATION));


        toggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (toggleButton.getText().toString().equalsIgnoreCase("JRV - O")) {
                    toggleButton.setChecked(false);
                    toggleButton.setBackgroundColor(getResources().getColor(R.color.dark_gray));
                } else if (toggleButton.getText().toString().equalsIgnoreCase("JRV - 1")) {
                    toggleButton.setChecked(true);
                    toggleButton.setBackgroundColor(getResources().getColor(R.color.green));

                }
            }
        });

//        ArrayList<ButtonModel> list = new ArrayList<>();
//
//        ButtonModel buttonModel = new ButtonModel("GF", button);
//        ButtonModel buttonModel1 = new ButtonModel("1", button);
//        ButtonModel buttonModel2 = new ButtonModel("7", button);
//        ButtonModel buttonModel3 = new ButtonModel("8", button);
//
//
//        list.add(buttonModel);
//        list.add(buttonModel1);
//        list.add(buttonModel2);
//        list.add(buttonModel3);
//
//
//        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
//        //Collections.reverse(list);
//        adapter = new ButtonAdapter(LiftControlsMain.this, list,
//                up_layout, up_icon, home, down_layout, down_icon, LED,
//                email);
//        recyclerView.setHasFixedSize(true);
//        recyclerView.setLayoutManager(new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, true));
//        recyclerView.setAdapter(adapter);
//        recyclerView.smoothScrollToPosition(list.size());

        getSignal(email, "first");


        // Updating Buttons....
        animZoomOut = AnimationUtils.loadAnimation(LiftControlsMain.this,
                R.anim.zoom_out_new);

        final Vibrator vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        rll_gf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                vibe.vibrate(30);
                updateButton(email, 1);
                rll_gf.startAnimation(animZoomOut);

                rll_gf.setBackground(getResources().getDrawable(R.drawable.state_pressed));
                btn_text_gf.setTextColor(getResources().getColor(R.color.red));

                LED.setText("GF");

                disableOther();

                final Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //Do something after 1500ms
                        rll_gf.clearAnimation();
                        rll_gf.setBackground(getResources().getDrawable(R.drawable.numbers_button));
                        btn_text_gf.setTextColor(getResources().getColor(R.color.black));
                    }
                }, 1500);
            }
        });
        rll_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                vibe.vibrate(30);
                updateButton(email, 2);
                rll_1.startAnimation(animZoomOut);

                rll_1.setBackground(getResources().getDrawable(R.drawable.state_pressed));
                btn_text_1.setTextColor(getResources().getColor(R.color.red));

                LED.setText("1");

                disableOther();

                final Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //Do something after 1500ms
                        rll_1.clearAnimation();
                        rll_1.setBackground(getResources().getDrawable(R.drawable.numbers_button));
                        btn_text_1.setTextColor(getResources().getColor(R.color.black));
                    }
                }, 1500);
            }
        });

        rll_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                vibe.vibrate(30);
                updateButton(email, 3);
                rll_7.startAnimation(animZoomOut);

                rll_7.setBackground(getResources().getDrawable(R.drawable.state_pressed));
                btn_text_7.setTextColor(getResources().getColor(R.color.red));

                LED.setText("7");

                disableOther();

                final Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //Do something after 1500ms
                        rll_7.clearAnimation();
                        rll_7.setBackground(getResources().getDrawable(R.drawable.numbers_button));
                        btn_text_7.setTextColor(getResources().getColor(R.color.black));
                    }
                }, 1500);
            }
        });

        rll_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                vibe.vibrate(30);
                updateButton(email, 4);
                rll_8.startAnimation(animZoomOut);

                rll_8.setBackground(getResources().getDrawable(R.drawable.state_pressed));
                btn_text_8.setTextColor(getResources().getColor(R.color.red));

                LED.setText("8");

                disableOther();

                final Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //Do something after 1500ms
                        rll_8.clearAnimation();
                        rll_8.setBackground(getResources().getDrawable(R.drawable.numbers_button));
                        btn_text_8.setTextColor(getResources().getColor(R.color.black));
                    }
                }, 1500);
            }
        });


    }

    public void init() {

        Intent intent = getIntent();
        email = intent.getStringExtra("email");
        lift_name = intent.getStringExtra("lift_name");

        toggleButton = findViewById(R.id.toggleButton);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        TextView tv = findViewById(R.id.tv);
        tv.setText(lift_name);

        up_layout = findViewById(R.id.up_layout);
        up_icon = findViewById(R.id.up_icon);
        home = findViewById(R.id.home);
        down_layout = findViewById(R.id.down_layout);
        down_icon = findViewById(R.id.down_icon);
        LED = findViewById(R.id.led_digital);

        // relative  layouts...
        rll_1 = findViewById(R.id.rll_1);
        rll_7 = findViewById(R.id.rll_7);
        rll_8 = findViewById(R.id.rll_8);
        rll_gf = findViewById(R.id.rll_gf);
        btn_text_8 = findViewById(R.id.btn_text_8);
        btn_text_7 = findViewById(R.id.btn_text_7);
        btn_text_1 = findViewById(R.id.btn_text_1);
        btn_text_gf = findViewById(R.id.btn_text_gf);

    }


    public void disableOther() {

        rll_8.setEnabled(false);
        rll_7.setEnabled(false);
        rll_1.setEnabled(false);
        rll_gf.setEnabled(false);

        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //Do something after 1500ms

                rll_8.setEnabled(true);
                rll_7.setEnabled(true);
                rll_1.setEnabled(true);
                rll_gf.setEnabled(true);

            }
        }, 3000);

    }


    private void getSignal(String email1, String method) {

        final String url = "http://lift.tfftours.com/new/getSignal.php?username=" + email1 + "method=" + method;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        // Toast.makeText(Splash_Activity.this, ""+response, Toast.LENGTH_SHORT).show();


                        try {
                            JSONArray jsonArray = response.getJSONArray("data");

                            // Toast.makeText(Admin_Home.this, ""+response, Toast.LENGTH_SHORT).show();

                            for (int i = 0; i < jsonArray.length(); i++) {


                                JSONObject notifications = jsonArray.getJSONObject(i);


                                id = notifications.getString("id");
                                username = notifications.getString("username");
                                lift_movement = notifications.getString("lift_movement");
                                time = notifications.getString("time");

                            }


                            animBlink = AnimationUtils.loadAnimation(LiftControlsMain.this,
                                    R.anim.blink);

                            up_icon.clearAnimation();
                            down_icon.clearAnimation();


                            if ("UP".equals(lift_movement)) {
                                up_icon.startAnimation(animBlink);
                                up_icon.setTextColor(getResources().getColor(R.color.red));
                                // removing other...
                                down_icon.clearAnimation();
                                down_icon.setTextColor(getResources().getColor(R.color.white));
                                home.setTextColor(getResources().getColor(R.color.white));


                            } else if ("DOWN".equals(lift_movement)) {
                                down_icon.startAnimation(animBlink);
                                down_icon.setTextColor(getResources().getColor(R.color.red));
                                // removing other...
                                up_icon.clearAnimation();
                                up_icon.setTextColor(getResources().getColor(R.color.white));
                                home.setTextColor(getResources().getColor(R.color.white));

                            } else if ("REST".equals(lift_movement)) {

                                home.setTextColor(getResources().getColor(R.color.green));
                                // removing other...
                                up_icon.clearAnimation();
                                up_icon.setTextColor(getResources().getColor(R.color.white));
                                down_icon.clearAnimation();
                                down_icon.setTextColor(getResources().getColor(R.color.white));
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                            // stop animating Shimmer and hide the layout

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();
                // customToast(error.getMessage());

            }
        });


        // Creating RequestQueue.
        RequestQueue requestQueue = Volley.newRequestQueue(LiftControlsMain.this);
        requestQueue.add(request);

    }


    // Update Button...
    private void updateButton(final String username, final int status) {


        try {

            String HttpURL = "http://lift.tfftours.com/new/updateButton.php";


            StringRequest request = new StringRequest(Request.Method.POST, HttpURL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }

            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {


                    // DataBase entries....
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("username", username);
                    params.put("status", String.valueOf(status));


                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(LiftControlsMain.this);
            requestQueue.add(request);


        } catch (Exception e) {
        }

    }
}