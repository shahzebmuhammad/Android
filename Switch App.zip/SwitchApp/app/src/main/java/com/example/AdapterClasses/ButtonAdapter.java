package com.example.AdapterClasses;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ModelClasses.ButtonModel;
import com.example.SwitchApp.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ButtonAdapter extends RecyclerView.Adapter<ButtonAdapter.ViewHolder> {
    private ArrayList<ButtonModel> listdata;
    Context context;
    TextView up_layout, up_icon, home, down_layout, down_icon, LED;
    String email;
    String state;

    Animation
            animFadeIn, animFadeOut, animBlink, animZoomIn, animZoomOut, animRotate, animMove, animSlideUp, animSlideDown, animBounce, animSequential, animTogether, animCrossFadeIn, animCrossFadeOut;
    public boolean Selected = false;


    // RecyclerView recyclerView;
    public ButtonAdapter(Context context, ArrayList<ButtonModel> listdata,
                         TextView up_layout, TextView up_icon, TextView home, TextView down_layout, TextView down_icon,
                         TextView LED, String email) {
        this.listdata = listdata;
        this.context = context;
        this.email = email;

        // Text views...

        this.up_layout = up_layout;
        this.up_icon = up_icon;
        this.home = home;
        this.down_layout = down_layout;
        this.down_icon = down_icon;

        this.LED = LED;

    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.buttons_layout_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }


    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        final ButtonModel buttonModel = listdata.get(position);


        animZoomOut = AnimationUtils.loadAnimation(context,
                R.anim.zoom_out_new);

        final Vibrator vibe = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);

        holder.btn_text.setText(buttonModel.getBtn_text());


            holder.button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {



                    vibe.vibrate(30);
                    updateButton(email, position + 1);

                    holder.rll.startAnimation(animZoomOut);

                    holder.button.setBackground(context.getResources().getDrawable(R.drawable.state_pressed));
                    holder.btn_text.setTextColor(context.getResources().getColor(R.color.red));

                    LED.setText(buttonModel.getBtn_text());


                    final Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            //Do something after 1500ms
                            holder.rll.clearAnimation();
                            holder.button.setBackground(context.getResources().getDrawable(R.drawable.numbers_button));
                            holder.btn_text.setTextColor(context.getResources().getColor(R.color.black));

                            // holder.button.setEnabled(true);


                        }
                    }, 1500);


                }
            });



    }


    @Override
    public int getItemCount() {
        return listdata.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        RelativeLayout rll;
        public TextView btn_text;
        public ImageButton button;

        public ViewHolder(View itemView) {
            super(itemView);
            this.btn_text = (TextView) itemView.findViewById(R.id.btn_text);
            button = itemView.findViewById(R.id.button);
            rll = itemView.findViewById(R.id.rll);
        }
    }

    // Update Button...
    private void updateButton(final String username, final int status) {


        try {

            String HttpURL = "http://lift.tfftours.com/updateButton.php";


            StringRequest request = new StringRequest(Request.Method.POST, HttpURL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }

            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {


                    // DataBase entries....
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("username", username);
                    params.put("status", String.valueOf(status));


                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(context);
            requestQueue.add(request);


        } catch (Exception e) {
        }

    }


}