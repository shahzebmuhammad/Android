package com.example.ModelClasses;

import android.widget.ImageButton;

public class ButtonModel {

     String btn_text;
     ImageButton button;


    public ButtonModel(String btn_text, ImageButton button) {
        this.btn_text = btn_text;
        this.button = button;
    }

    public String getBtn_text() {
        return btn_text;
    }

    public void setBtn_text(String btn_text) {
        this.btn_text = btn_text;
    }

    public ImageButton getButton() {
        return button;
    }

    public void setButton(ImageButton button) {
        this.button = button;
    }
}
