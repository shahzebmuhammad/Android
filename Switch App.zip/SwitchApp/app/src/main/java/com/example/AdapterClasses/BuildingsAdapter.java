package com.example.AdapterClasses;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ModelClasses.ButtonModel;
import com.example.SwitchApp.LiftControlsMain;
import com.example.SwitchApp.R;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;

public class BuildingsAdapter extends RecyclerView.Adapter<BuildingsAdapter.ViewHolder> {
    private ArrayList<ButtonModel> listdata;
    Context context;
    String email;

    // RecyclerView recyclerView;
    public BuildingsAdapter(Context context, ArrayList<ButtonModel> listdata, String email) {
        this.listdata = listdata;
        this.context = context;
        this.email = email;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.buildings_lift_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        final ButtonModel buttonModel = listdata.get(position);

        holder.building_text.setText(buttonModel.getBtn_text());

        if (position == 0) {
            holder.material_cardview.setCardBackgroundColor(context.getResources().getColor(R.color.green));
            holder.building_text.setTextColor(context.getResources().getColor(R.color.white));

            holder.material_cardview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(context, LiftControlsMain.class);
                    intent.putExtra("email",email);
                    intent.putExtra("lift_name",buttonModel.getBtn_text());

                    context.startActivity(intent);
                }
            });
        }


    }


    @Override
    public int getItemCount() {
        return listdata.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView building_text;
        MaterialCardView material_cardview;
        public SwitchCompat button;

        public ViewHolder(View itemView) {
            super(itemView);
            this.building_text = (TextView) itemView.findViewById(R.id.building_1);
            material_cardview = itemView.findViewById(R.id.material_cardview);
        }
    }
}