package com.example.SwitchApp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.Notifications.Config;
import com.example.Notifications.NotificationUtils;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.wang.avi.AVLoadingIndicatorView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SignIn extends AppCompatActivity {

    Button btn_signIn;
    TextView signup;
    TextInputLayout email_text_input_layout, password_text_input_layout;
    EditText email, password;

    String db_username, db_password, db_userid, db_userlevel, db_email, db_timestamp, db_parent_directory, db_firstname, db_lastname;

    AVLoadingIndicatorView loading_style;

    SessionManager session;

    private BroadcastReceiver mRegistrationBroadcastReceiver;
    String regId;
    String deviceToken;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        // get user data from session
    /*    session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();
        String key_username = user.get(SessionManager.KEY_NAME);
        String key_level = user.get(SessionManager.KEY_LEVEL);

        if (session.isLoggedIn() == true) {
            // User is signed in (getCurrentUser() will be null if not signed in)
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("current_user", key_username);
            intent.putExtra("level", key_level);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }*/

        init();

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignIn.this, SignUp.class);
                startActivity(intent);
            }
        });

        email.addTextChangedListener(new ValidationTextWatcher(email));
        password.addTextChangedListener(new ValidationTextWatcher(password));

        // Capture button clicks
        btn_signIn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {


                if (!validateEmail()) {
                    return;
                } else if (!validatePassword()) {
                    return;
                } else {


                    UserLogin(email.getText().toString().trim(), password.getText().toString().trim());
                }


            }
        });

        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(new OnSuccessListener<InstanceIdResult>() {
            @Override
            public void onSuccess(InstanceIdResult instanceIdResult) {
                deviceToken = instanceIdResult.getToken();
                // Do whatever you want with your token now
                // i.e. store it on SharedPreferences or DB
                // or directly send it to server
            }
        });
        registerBroadcastRecieverforToken();


    }

    private void registerBroadcastRecieverforToken() {

        // Notification...
        mRegistrationBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                // checking for type intent filter
                if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                    // gcm successfully registered
                    // now subscribe to `global` topic to receive app wide notifications
                    FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);

                    //  displayFirebaseRegId();

                } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                    // new push notification is received

                    String message = intent.getStringExtra("message");


                    //  txtMessage.setText(message);
                }
            }
        };
    }

    public void init() {

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        email_text_input_layout = findViewById(R.id.email_input_layout);
        password_text_input_layout = findViewById(R.id.password_input_layout);
        signup = findViewById(R.id.signUp);
        btn_signIn = findViewById(R.id.btn_signIn);

        loading_style = findViewById(R.id.avi);

    }


    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    private boolean validatePassword() {
        if (password.getText().toString().trim().isEmpty()) {
            password_text_input_layout.setError("Password is required");
            requestFocus(password);
            return false;
        } else if (password.getText().toString().length() < 6) {
            password_text_input_layout.setError("Password can't be less than 6 digit");
            requestFocus(password);
            return false;
        } else {
            password_text_input_layout.setErrorEnabled(false);
        }
        return true;
    }

    private boolean validateEmail() {
        if (email.getText().toString().trim().isEmpty()) {
            email_text_input_layout.setError("Email can't be empty");
            requestFocus(email);
            return false;
        } else {
            String emailId = email.getText().toString();
            Boolean isValid = android.util.Patterns.EMAIL_ADDRESS.matcher(emailId).matches();
            if (!isValid) {
                email_text_input_layout.setError("Invalid Email address, ex: abc@example.com");
                requestFocus(email);
                return false;
            } else {
                email_text_input_layout.setErrorEnabled(false);
            }
        }
        return true;
    }

    private class ValidationTextWatcher implements TextWatcher {

        private View view;

        private ValidationTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void afterTextChanged(Editable editable) {
            switch (view.getId()) {

                case R.id.email:
                    validateEmail();
                    break;

                case R.id.password:
                    validatePassword();
                    break;
            }
        }
    }


    private void UserLogin(final String EmailHolder, final String PasswordHolder) {

        loading_style.smoothToShow();


        String url = "http://lift.tfftours.com/new/SignIn.php?username=" + EmailHolder + "&password=" + PasswordHolder+ "&token_id=" + deviceToken;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {


                        try {
                            JSONArray jsonArray = response.getJSONArray("user");

                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject users = jsonArray.getJSONObject(i);


                                db_username = users.getString("username");
                                db_password = users.getString("password");
                                db_userid = users.getString("userid");
                                db_userlevel = users.getString("userlevel");
                                db_email = users.getString("email");
                                db_timestamp = users.getString("timestamp");
                                db_parent_directory = users.getString("parent_directory");
                                db_firstname = users.getString("firstname");
                                db_lastname = users.getString("lastname");


                            }




                            if (db_username.isEmpty()) {
                                Toast.makeText(SignIn.this, "Username Or Password Is Incorrect!", Toast.LENGTH_SHORT).show();

                            }else {

                                Intent intent = new Intent(SignIn.this, BuildingLifts.class);
                                intent.putExtra("current_user", db_username);
                                intent.putExtra("level", db_userlevel);
                                startActivity(intent);
                                finish();


                            }



                            loading_style.smoothToHide();

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(SignIn.this, "Username Or Password Is Incorrect!", Toast.LENGTH_SHORT).show();
                            loading_style.smoothToHide();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                error.printStackTrace();

              //  Toast.makeText(SignIn.this, ""+error.toString(), Toast.LENGTH_LONG).show();

                loading_style.smoothToHide();

                if (error instanceof NoConnectionError) {
                 final AlertDialog.Builder alertDialog=   new AlertDialog.Builder(SignIn.this);
                 alertDialog.setMessage(
                            "Unable to connect to the server. Please ensure your internet is working!");
                 alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                     @Override
                     public void onClick(DialogInterface dialog, int which) {

                         dialog.dismiss();
                     }
                 });

                 alertDialog.show();
                }
            }
        });


        // Creating RequestQueue.
        RequestQueue requestQueue = Volley.newRequestQueue(SignIn.this);

        // Adding the StringRequest object into requestQueue.
        requestQueue.add(request);


    }

    @Override
    public void onResume() {
        super.onResume();
        // register GCM registration complete receiver
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
                new IntentFilter(Config.REGISTRATION_COMPLETE));

        // register new push message receiver
        // by doing this, the activity will be notified each time a new message arrives
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
                new IntentFilter(Config.PUSH_NOTIFICATION));

        // clear the notification area when the app is opened
        NotificationUtils.clearNotifications(getApplicationContext());


    }

    @Override
    public void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);

        super.onPause();
    }
    // Fetches reg id from shared preferences
    // and displays on the screen
    private void displayFirebaseRegId() {
        SharedPreferences pref = getApplicationContext().getSharedPreferences(Config.SHARED_PREF, 0);
        regId = pref.getString("regId", null);

        //  Log.e(TAG, "Firebase reg id: " + regId);
        if (!TextUtils.isEmpty(regId))
            //   txtRegId.setText("Firebase Reg Id: " + regId);
            Toast.makeText(this, "" + regId, Toast.LENGTH_SHORT).show();
        else
            // txtRegId.setText("Firebase Reg Id is not received yet!");
            Toast.makeText(this, "Firebase Reg Id is not received yet!", Toast.LENGTH_SHORT).show();
    }
}