package com.example.SwitchApp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;

public class SignUp extends AppCompatActivity {

    TextView signin;
    Button btn_signUp;
    TextInputLayout email_text_input_layout, password_text_input_layout, confirm_password_text_input_layout,
            first_name_input_layout, last_name_input_layout;
    EditText email, password, first_name, last_name, confirm_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        init();

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignUp.this, SignIn.class);
                startActivity(intent);
            }
        });

        first_name.addTextChangedListener(new SignUp.ValidationTextWatcher(first_name));
        last_name.addTextChangedListener(new SignUp.ValidationTextWatcher(last_name));
        email.addTextChangedListener(new SignUp.ValidationTextWatcher(email));
        password.addTextChangedListener(new SignUp.ValidationTextWatcher(password));
        confirm_password.addTextChangedListener(new SignUp.ValidationTextWatcher(confirm_password));

        // Capture button clicks
        btn_signUp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                if (!validateFirstname()) {
                    return;
                } else if (!validateLastname()) {
                    return;
                } else if (!validateEmail()) {
                    return;
                } else if (!validatePassword()) {
                    return;
                } else if (!validateConfirmpassword()) {
                    return;
                } else {

                    Intent intent = new Intent(SignUp.this, MainActivity.class);
                    startActivity(intent);
                }


            }
        });
    }

    public void init() {
        signin = findViewById(R.id.signIn);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        email_text_input_layout = findViewById(R.id.email_input_layout);
        password_text_input_layout = findViewById(R.id.password_input_layout);
        confirm_password_text_input_layout = findViewById(R.id.confirm_password_input_layout);
        first_name = findViewById(R.id.first_name);
        last_name = findViewById(R.id.last_name);
        confirm_password = findViewById(R.id.confirm_password);
        btn_signUp = findViewById(R.id.btn_signUp);
        first_name_input_layout = findViewById(R.id.first_name_input_layout);
        last_name_input_layout = findViewById(R.id.last_name_input_layout);

    }

    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    private boolean validatePassword() {
        if (password.getText().toString().trim().isEmpty()) {
            password_text_input_layout.setError("Password is required");
            requestFocus(password);
            return false;
        } else if (password.getText().toString().length() < 6) {
            password_text_input_layout.setError("Password can't be less than 6 digit");
            requestFocus(password);
            return false;
        } else {
            password_text_input_layout.setErrorEnabled(false);
        }
        return true;
    }

    private boolean validateEmail() {
        if (email.getText().toString().trim().isEmpty()) {
            email_text_input_layout.setError("Email can't be empty");
            requestFocus(email);
            return false;
        } else {
            String emailId = email.getText().toString();
            Boolean isValid = android.util.Patterns.EMAIL_ADDRESS.matcher(emailId).matches();
            if (!isValid) {
                email_text_input_layout.setError("Invalid Email address, ex: abc@example.com");
                requestFocus(email);
                return false;
            } else {
                email_text_input_layout.setErrorEnabled(false);
            }
        }
        return true;
    }

    private boolean validateConfirmpassword() {
        if (!confirm_password.getText().toString().trim().equals(password.getText().toString().trim())) {
            confirm_password_text_input_layout.setError("Password mismatches");
            requestFocus(confirm_password);
            return false;
        } else {
            confirm_password_text_input_layout.setErrorEnabled(false);
        }
        return true;
    }

    private boolean validateFirstname() {
        if (first_name.getText().toString().trim().isEmpty()) {
            first_name_input_layout.setError("First name can't be empty");
            requestFocus(first_name);
            return false;
        } else {
            first_name_input_layout.setErrorEnabled(false);
        }
        return true;
    }

    private boolean validateLastname() {
        if (last_name.getText().toString().trim().isEmpty()) {
            last_name_input_layout.setError("Last name can't be empty");
            requestFocus(last_name);
            return false;
        } else {
            last_name_input_layout.setErrorEnabled(false);
        }
        return true;
    }

    private class ValidationTextWatcher implements TextWatcher {

        private View view;

        private ValidationTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void afterTextChanged(Editable editable) {
            switch (view.getId()) {
                case R.id.first_name:
                    validateFirstname();
                    break;
                case R.id.last_name:
                    validateLastname();
                    break;
                case R.id.email:
                    validateEmail();
                    break;
                case R.id.password:
                    validatePassword();
                    break;
                case R.id.confirm_password:
                    validateConfirmpassword();
                    break;
            }
        }
    }
}