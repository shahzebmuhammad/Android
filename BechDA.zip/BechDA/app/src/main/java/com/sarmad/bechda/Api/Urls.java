package com.sarmad.bechda.Api;

public class Urls {

    //All Urls Are Post

    public static String CreateProduct ="http://biztechengg.com/sarmad/Api/createProduct.php";

    public static String Apikey ="apikey?Bookdisbookdfor^u@XzBechDa";

    public static String createProductImage ="http://biztechengg.com/sarmad/Api/uploadProductImages.php";

    public  static  String getProducts="http://biztechengg.com/sarmad/Api/getProducts.php";

    public static String imagebase="http://biztechengg.com/sarmad/Api/omg/";

    public static String login="http://biztechengg.com/sarmad/Api/login.php";

    public static String validateUser="http://biztechengg.com/sarmad/Api/validateUser.php";

    public static String Register="http://biztechengg.com/sarmad/Api/register.php";

    public static String getproductDetails="http://biztechengg.com/sarmad/Api/getProductDetail.php";

    public static String UpdateProfile="http://biztechengg.com/sarmad/Api/updateProfile.php";

    public static String getProductsByID="http://biztechengg.com/sarmad/Api/getProductsbyid.php";

    public static String deleteProduct="http://biztechengg.com/sarmad/Api/deleteProduct.php";

    public static String updatePasswoord="http://biztechengg.com/sarmad/Api/updatePassword.php";

    public static String updateNotifications="http://biztechengg.com/sarmad/Api/updatenotifications.php";

    public static String verifyPhone="http://biztechengg.com/sarmad/Api/verify_phone.php";

    public static String newpassword="http://biztechengg.com/sarmad/Api/newpassword.php";

    public static String serachByName="http://biztechengg.com/sarmad/Api/search.php";

    public static String serachByType="http://biztechengg.com/sarmad/Api/searchByType.php";

}
