package com.sarmad.bechda.passwords;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.sarmad.bechda.MainActivity;
import com.sarmad.bechda.R;
import com.sarmad.bechda.user.LoginActivity;
import com.sarmad.bechda.user.Register;
import com.sarmad.bechda.user.VerifyPhone;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.sarmad.bechda.Api.Urls.Apikey;
import static com.sarmad.bechda.Api.Urls.login;
import static com.sarmad.bechda.Api.Urls.validateUser;
import static com.sarmad.bechda.Api.Urls.verifyPhone;

public class ForgetPassword extends AppCompatActivity {

    private EditText edditphone_number;
    private String userphone;
    RequestQueue queue;
    KProgressHUD hud;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
        queue = Volley.newRequestQueue(this);
        edditphone_number = findViewById(R.id.phone_number);

        final String prefix = "+92";
        edditphone_number.setText(prefix);
    }


    public void AttemptLogin() {
        StringRequest postRequest = new StringRequest(Request.Method.POST, verifyPhone,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.i("resper", response);
                        hideProgress();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String responsestatus = jsonObject.getString("status");
                            if (!responsestatus.isEmpty() && responsestatus.equals("invalid Credentials")) {
                                hideProgress();
                                Toast.makeText(getApplicationContext(), "phone Number not found", Toast.LENGTH_SHORT).show();
                            }
                            else if (responsestatus.equals("success")) {

                                JSONArray parentJsonArray = jsonObject.getJSONArray("response");
                                for (int i = 0; i < parentJsonArray.length(); i++) {
                                    JSONObject childJsonObject = (JSONObject) parentJsonArray.get(i);

                                    String name = childJsonObject.getString("name");
                                    String email = childJsonObject.getString("email");
                                    String phone = childJsonObject.getString("phone");
                                    String id = childJsonObject.getString("id");

                                    Intent intent = new Intent(ForgetPassword.this, verification_code.class);
                                    intent.putExtra("userphone", userphone);
                                    intent.putExtra("id", id);
                                    startActivity(intent);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Something went wrong try again", Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("apikey", Apikey);
                params.put("phone", userphone);
                return params;
            }
        };

        queue.add(postRequest);
        showProgress();
    }

    public void showProgress() {
        hud = KProgressHUD.create(ForgetPassword.this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Please Wait")
                .setCancellable(true)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f)
                .show();
    }

    public void hideProgress() {
        hud.dismiss();
    }

    public void recover(View view) {
        userphone = edditphone_number.getText().toString();
        if ((userphone.equals("") || userphone.toString().length() > 13 || userphone.toString().length() < 13) || !(userphone.startsWith("+92"))) {
            edditphone_number.setError("invalid Phone number");
            edditphone_number.requestFocus();
            return;
        }
        else {
            AttemptLogin();
        }
    }
}