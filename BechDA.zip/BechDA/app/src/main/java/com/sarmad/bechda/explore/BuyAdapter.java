package com.sarmad.bechda.explore;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputLayout;
import com.sarmad.bechda.R;
import com.sarmad.bechda.sell.SellActivity;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class BuyAdapter extends RecyclerView.Adapter<BuyAdapter.MyViewHolder> implements Filterable {

    private LayoutInflater inflater;
    private ArrayList<DetailsModel> dataModelArrayList;
    private Context mcontext;
    private BuyAdapter.OnItemClickListner mlistener;
    private ArrayList<DetailsModel> filteredList;
    private ArrayList<DetailsModel> orignalList;

    public interface OnItemClickListner { void onItemClicked(int position);}

    public void setOnItemClickListner(BuyAdapter.OnItemClickListner listener) { mlistener= listener; }

    public BuyAdapter(Context ctx, ArrayList<DetailsModel> dataModelArrayList){
        mcontext=ctx;
        inflater = LayoutInflater.from(ctx);
        this.dataModelArrayList = dataModelArrayList;
        filteredList = new ArrayList<>(dataModelArrayList);
        orignalList=  new ArrayList<>(dataModelArrayList);
    }

    @Override
    public BuyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.card_buy, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(BuyAdapter.MyViewHolder holder, int position) {

        holder.name.setText( dataModelArrayList.get(position).getName());
        holder.price.setText("Rs "+dataModelArrayList.get(position).getPrice());
        holder.location.setText(dataModelArrayList.get(position).getLocation());
        Picasso.get().load(dataModelArrayList.get(position).getTitleImaage()).into(holder.image);
    }

    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView  name, price,location;
        ImageView image;
        Spinner locationspinner;

        public MyViewHolder(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.name);
            price = itemView.findViewById(R.id.price);
            location = itemView.findViewById(R.id.location);
            image=  itemView.findViewById(R.id.thumbnail);
            locationspinner= itemView.findViewById(R.id.product_location);
            image.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if(pos != RecyclerView.NO_POSITION){
                        if(mlistener!=null)
                        {
                            int position= getAdapterPosition();
                            if(position!= RecyclerView.NO_POSITION){
                                mlistener.onItemClicked(position);
                            }
                        }
                    }
                }
            });
        }
    }

    @Override
    public Filter getFilter() {
        return LocationFilter;
    }
    private Filter LocationFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            dataModelArrayList.clear();
            dataModelArrayList.addAll(orignalList);
            ArrayList<DetailsModel> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(dataModelArrayList);
            }
            else if (constraint.equals("All")) {
                filteredList.addAll(dataModelArrayList);
            }
            else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (DetailsModel item : dataModelArrayList) {
                    if (item.getLocation().toLowerCase().contains(filterPattern)||item.getName().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            dataModelArrayList.clear();
            dataModelArrayList.addAll((ArrayList) results.values);
            notifyDataSetChanged();
        }
    };

}

