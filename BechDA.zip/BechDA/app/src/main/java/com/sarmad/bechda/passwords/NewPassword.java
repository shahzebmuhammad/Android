package com.sarmad.bechda.passwords;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.sarmad.bechda.Api.Urls;
import com.sarmad.bechda.MainActivity;
import com.sarmad.bechda.R;
import com.sarmad.bechda.user.ChangePassword;
import com.sarmad.bechda.user.LoginActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.sarmad.bechda.Api.Urls.Apikey;
import static com.sarmad.bechda.Api.Urls.newpassword;
import static com.sarmad.bechda.Api.Urls.validateUser;


public class NewPassword extends AppCompatActivity {

    RequestQueue queue;
    KProgressHUD hud;

    String userpassword ;
    String userconfirmpassword ;

    EditText edditpassword;
    EditText edditConfirmpassword;
    String userid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_password);
        queue = Volley.newRequestQueue(this);
        edditpassword = findViewById(R.id.password);
        edditConfirmpassword = findViewById(R.id.confirm_password);
        Intent intent = getIntent();
        userid=intent.getStringExtra("id");
    }

    public void makenewpassword(View view) {

        userpassword = edditpassword.getText().toString();
        userconfirmpassword = edditConfirmpassword.getText().toString();

        if (userpassword.length() < 8 || !(isValidPassword(userpassword))) {
            edditpassword.setError("Password must contain at least 8 characters! One special characters. !@#$%^&*)");
            edditpassword.requestFocus();
            return;
        }

        if (!(userpassword.equals(userconfirmpassword))){
            edditConfirmpassword.setError("Password don't match");
            edditConfirmpassword.requestFocus();
            return;
        }
        else
        {
          makeUpdate(userpassword);
        }
    }

    public static boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();

    }

    public void makeUpdate(final String newpassword)
    {

        StringRequest postRequest = new StringRequest(Request.Method.POST, Urls.newpassword,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        hideProgress();
                        Log.i("resper",response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String responsestatus = jsonObject.getString("status");

                            if(responsestatus.equals("success")) {

                                String status = jsonObject.getString("data");

                                 if(status.equals("updated"))
                                {
                                    AlertDialog alertDialog = new AlertDialog.Builder(NewPassword.this).create();
                                    alertDialog.setTitle("Updated");
                                    alertDialog.setMessage("your Password is now updated");
                                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    Intent intent = new Intent(NewPassword.this, LoginActivity.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                    startActivity(intent);
                                                }
                                            });
                                    alertDialog.show();
                                }

                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(),response.toString(),Toast.LENGTH_SHORT).show();
                            }
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        hideProgress();

                        Toast.makeText(getApplicationContext(),"Something went wrong try again",Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("apikey", Urls.Apikey);
                params.put("new_password", newpassword);
                params.put("id", userid);
                return params;
            }
        };
        queue.add(postRequest);
        showProgress();
    }

    public void showProgress()
    {
        hud= KProgressHUD.create(NewPassword.this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Please Wait")
                .setCancellable(true)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f)
                .show();
    }
    public void hideProgress()
    { hud.dismiss(); }
    @Override
    public void onBackPressed() { Toast.makeText(getApplicationContext(),"You Cannot Go back at this Stage",Toast.LENGTH_LONG).show(); }

}