package com.sarmad.bechda.Api;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiService {
    @POST("uploadProductImages.php")
    Call<Response> event_store(@Body RequestBody file);
}