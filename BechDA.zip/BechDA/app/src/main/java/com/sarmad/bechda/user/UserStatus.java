package com.sarmad.bechda.user;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

public class UserStatus {

    Context context;

    public UserStatus(Context mContext) {

        this.context= mContext;

    }
    public  Boolean isUserLoggedIn()
    {
        SharedPreferences loginPref = context.getSharedPreferences("loginPref", 0); // 0 - for private mode
        Boolean islogged = loginPref.getBoolean("status",false);

        if(islogged)
        {
            return true;
        }
        else{
            return false;
        }
    }

}
