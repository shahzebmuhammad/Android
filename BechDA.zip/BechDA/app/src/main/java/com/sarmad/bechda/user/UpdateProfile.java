package com.sarmad.bechda.user;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.sarmad.bechda.Api.Urls;
import com.sarmad.bechda.MainActivity;
import com.sarmad.bechda.R;
import com.sarmad.bechda.sell.SellActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.sarmad.bechda.Api.Urls.Apikey;
import static com.sarmad.bechda.Api.Urls.validateUser;

public class UpdateProfile extends AppCompatActivity {
    EditText name , email, phoneNumber;
    String uid;
    private String customerId,newsletter;
    RequestQueue queue;
    KProgressHUD hud;
    Switch aSwitch;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);

        queue = Volley.newRequestQueue(this);
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        phoneNumber = findViewById(R.id.phone_number);


        SharedPreferences loginPref = getApplicationContext().getSharedPreferences("loginPref", 0); // 0 - for private mode
        final Boolean islogged = loginPref.getBoolean("status",false);
        String sname =  loginPref.getString("name",null);
        String semail = loginPref.getString("email",null);
        String sphone = loginPref.getString("phone",null);
        customerId = loginPref.getString("id",null);
        newsletter = loginPref.getString("newsletter",null);

        name.setText(sname);
        email.setText(semail);
        phoneNumber.setText(sphone);

       ImageView back_button = findViewById(R.id.btn_back);

        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });



    }

    public void updateProfile(View view) {


       String username = name.getText().toString();
       String useremail = email.getText().toString();
       String userphone = phoneNumber.getText().toString();


        if(TextUtils.isEmpty(username) || username.length()<3)
        {
            name.setError("Provide a valid name");
            name.requestFocus();
            return;
        }
        else if(TextUtils.isEmpty(useremail) || !(useremail.toString().contains("@")))
        {
            email.setError("Provide a Valid Email Address");
            email.requestFocus();
            return;
        }
        if ((userphone.equals("")|| userphone.toString().length()>13||userphone.toString().length()<13)||!(userphone.startsWith("+92"))){
            phoneNumber.setError("invalid Phone number");
            phoneNumber.requestFocus();
        }
        else
        {
            makeUpdate(username,useremail,userphone);
        }

    }

    public void makeUpdate(final String username, final String useremail, final String userphone)
    {

        SharedPreferences pref = getApplicationContext().getSharedPreferences("loginPref", 0); // 0 - for private mode
        editor = pref.edit();

        StringRequest postRequest = new StringRequest(Request.Method.POST, Urls.UpdateProfile,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.i("resper",response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String responsestatus = jsonObject.getString("status");
                             if(responsestatus.equals("success")) {

                                JSONArray parentJsonArray = jsonObject.getJSONArray("data");
                                for (int i = 0; i < parentJsonArray.length(); i++) {
                                    JSONObject childJsonObject = (JSONObject) parentJsonArray.get(i);

                                    String name = childJsonObject.getString("name");
                                    String email = childJsonObject.getString("email");
                                    String phone = childJsonObject.getString("phone");
                                    String id = childJsonObject.getString("id");

                                    editor.putString("name",name);
                                    editor.putString("email",email);
                                    editor.putString("phone",phone);
                                    editor.apply();
                                    hideProgress();

                                }
                                 AlertDialog alertDialog = new AlertDialog.Builder(UpdateProfile.this).create();
                                 alertDialog.setTitle("Updated");
                                 alertDialog.setMessage("your profile is now updated");
                                 alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                         new DialogInterface.OnClickListener() {
                                             public void onClick(DialogInterface dialog, int which) {
                                                 Intent intent = new Intent(UpdateProfile.this, MainActivity.class);
                                                 intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                 startActivity(intent);
                                             }
                                         });
                                 alertDialog.show();
                            }
                             else
                             {
                                 Toast.makeText(getApplicationContext(),response.toString(),Toast.LENGTH_SHORT).show();
                             }
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        hideProgress();

                        Toast.makeText(getApplicationContext(),"Something went wrong try again",Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("name", username);
                params.put("apikey", Urls.Apikey);
                params.put("email", useremail);
                params.put("phone", userphone);
                params.put("id", customerId);
                return params;
            }
        };
        queue.add(postRequest);
        showProgress();
    }
    public void showProgress()
    {
        hud= KProgressHUD.create(UpdateProfile.this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Updating")
                .setCancellable(true)
                .setAnimationSpeed(2)
                .show();
    }
    public void hideProgress()
    {

        hud.dismiss();
    }



}
