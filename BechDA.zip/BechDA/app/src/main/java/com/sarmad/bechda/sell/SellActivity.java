package com.sarmad.bechda.sell;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.androidnetworking.interfaces.UploadProgressListener;
import com.asksira.bsimagepicker.BSImagePicker;
import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputLayout;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.sarmad.bechda.Api.ApiClient;
import com.sarmad.bechda.Api.ApiService;
import com.sarmad.bechda.Api.Urls;
import com.sarmad.bechda.MainActivity;
import com.sarmad.bechda.user.LoginActivity;
import com.sarmad.bechda.R;

import net.alhazmy13.mediapicker.Image.ImagePicker;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

public class SellActivity extends AppCompatActivity implements BSImagePicker.OnSingleImageSelectedListener,BSImagePicker.OnMultiImageSelectedListener, BSImagePicker.ImageLoaderDelegate  {
    int galleryCheck, locationCheck;
    private Button chooseImage;
    private ImageView image1;
    private ImageView image2;
    private ImageView image3;
    private TextView imageCounter;
    private ImageView currentLocation;
    private Button submitButton;
    LocationManager locationManager;
    LocationListener locationListener;
    public Double lat;
    public Double lng;
    private EditText productName;
    private EditText productPrice;
    private EditText producDetail;
    private Spinner productType;
    private Spinner productLocation;
    List<String> mPaths;
    RequestQueue queue;
    int selectedImgaes=0;
    int uploadedImages=0;
    int imageFlag=0;
    private  String pName, pPrice,pDetails,ptype,pLocation,_customerId;
    public   KProgressHUD hud;
    ProgressDialog dialog;
    String autoCity="";
    ImageView back_button;
    private SweetAlertDialog pDialog;
    List<String> overallPaths;
    ArrayList<File> uploadingfiles = new ArrayList<File>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);
        intilizeLayouts();
        checkPermissions();
        SharedPreferences loginPref =getApplicationContext().getSharedPreferences("loginPref", 0); // 0 - for private mode
        final Boolean islogged = loginPref.getBoolean("status",false);
        String name =  loginPref.getString("name",null);
        String email = loginPref.getString("email",null);
        String phone = loginPref.getString("phone",null);
        _customerId = loginPref.getString("id",null);
        chooseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (uploadingfiles.size()>4)
                {
                    Toast.makeText(getApplicationContext(),"cannnot select more then 5 Images",Toast.LENGTH_SHORT).show();
                }
                else {
                    pickimage();
                }
            }
        });

        currentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    buildAlertMessageNoGps();
                }
                else {
                    getUserLocation();
                }
            }
        });
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateInputs();
            }
        });

       // Toast.makeText(getApplicationContext(),_customerId.toString(),Toast.LENGTH_LONG).show();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            }
        }
    }

    public Boolean checkLocationPermission()
    {
        Dexter.withActivity(SellActivity.this)
                .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                .withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse response) {
                        locationCheck=1;
                    }
                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse response) {

                        locationCheck=0;
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();

        if (locationCheck==0)
        {
            return false;
        }
        else  if (locationCheck==1)
        {
            return true;
        }
        return null;
    }
    public void requestLocation()
    {
        if(Build.VERSION.SDK_INT<23)
        {
            if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                dialog = new ProgressDialog(this);
                dialog.setMessage("Retrieving Location!");
                dialog.show();
            }
            else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
            }
        }
        else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {

                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);

                dialog = new ProgressDialog(this);
                dialog.setMessage("Retrieving Location!");
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();

            }
        }
    }
    private void getUserLocation()
    {
        if (checkLocationPermission()) {

            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {

                    dialog.dismiss();

                    lat = location.getLatitude();
                    lng = location.getLongitude();
                    Log.i("laatt", lat.toString());

                    if(lat.toString().equals("") && lng.toString().equals("")) {

                    }
                    else {
                        Geocoder geocoder = new Geocoder(SellActivity.this, Locale.getDefault());
                        List<Address> addresses = null;
                        try {
                            addresses = geocoder.getFromLocation(lat, lng, 1);
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                        }
                        String address = addresses.get(0).getSubLocality();
                        String cityName = addresses.get(0).getLocality();
                        productLocation.setVisibility(View.GONE);
                        TextInputLayout locationtextLayout = findViewById(R.id.l_location_text);
                        locationtextLayout.setVisibility(View.VISIBLE);
                        TextView locationtext = findViewById(R.id.locationname);
                        locationtext.setText(address+","+cityName.toString());

                        autoCity= cityName;

                        ImageView changeLocation= findViewById(R.id.chnageLocation);
                        changeLocation.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                TextInputLayout locationtextLayout = findViewById(R.id.l_location_text);
                                locationtextLayout.setVisibility(View.GONE);
                                productLocation.setVisibility(View.VISIBLE);
                            }
                        });
                        //Toast.makeText(getApplicationContext(),cityName.toString(),Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) { }
                @Override
                public void onProviderEnabled(String provider) { }
                @Override
                public void onProviderDisabled(String provider) { }
            };
            requestLocation();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Please Allow App to Access Location in Settings",Toast.LENGTH_LONG).show();
        }
    }

    private void intilizeLayouts()
    {
        chooseImage = findViewById(R.id.btn_imageUpload);
        image1 = findViewById(R.id.iv1);
        image2 = findViewById(R.id.iv2);
        image3 = findViewById(R.id.iv3);
        imageCounter = findViewById(R.id.imagecount);
        currentLocation= findViewById(R.id.current_location);

        productName= findViewById(R.id.product_name);
        productPrice = findViewById(R.id.Product_price);
        producDetail = findViewById(R.id.product_description);
        productType = findViewById(R.id.Product_type);
        productLocation = findViewById(R.id.product_location);
        submitButton = findViewById(R.id.btn_register);
        back_button = findViewById(R.id.btn_back);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               onBackPressed();
            }
        });
        mPaths= new ArrayList<>();
        queue = Volley.newRequestQueue(this);
    }
    private void validateInputs()
    {
        pName = productName.getText().toString();
        pPrice = productPrice.getText().toString();
        pDetails = producDetail.getText().toString();
        ptype= productType.getSelectedItem().toString();
        if (autoCity!=null &&!(autoCity.equals("")))
        {
            pLocation= autoCity;
        }
        else
        {
            pLocation= productLocation.getSelectedItem().toString();
        }

        Log.i("name",pName);
        Log.i("price",pPrice);
        Log.i("pdetails",pDetails);
        Log.i("type",ptype);
        Log.i("location",pLocation);

        if(TextUtils.isEmpty(pName) || pName.length()<3) {

            productName.setError("Provide a valid name Min 3 Characters");
            productName.requestFocus();
            return;
        }

        if(TextUtils.isEmpty(pPrice) || pPrice.length()<2) {

            productPrice.setError("Provide a valid Price Min 2 Characters");
            productPrice.requestFocus();
            return;
        }

        if(TextUtils.isEmpty(ptype)) {
            Toast.makeText(getApplicationContext(),"Product Type not selected",Toast.LENGTH_SHORT).show();
            return;
        }

        if(TextUtils.isEmpty(pDetails) || pDetails.length()<6 ||  pDetails.length()>100) {
                producDetail.setError("Provide a valid Description Min 6 and Max 100 Characters");
                producDetail.requestFocus();
                return;
        }
        if(imageFlag!=1) {
            Toast.makeText(getApplicationContext(),"Please Select at least 1 images",Toast.LENGTH_SHORT).show();
            return;
        }
        else
        {
            uploadProduct();
        }
    }
    private void uploadProduct()
    {
        String url = Urls.CreateProduct;
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.i("Respppp",response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String responsestatus = jsonObject.getString("status");
                            Log.i("Status",responsestatus);

                            if(!responsestatus.isEmpty()){
                                uploadMultiFile(responsestatus);
                             }
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                       pDialog.dismiss();
                        Toast.makeText(getApplicationContext(),"Internet Connection Error",Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("apikey",Urls.Apikey);
                params.put("name", pName);
                params.put("price", pPrice);
                params.put("type", ptype);
                params.put("location", pLocation);
                params.put("description", pDetails);
                params.put("custmer_id", _customerId);
                return params;
            }
        };
        queue.add(postRequest);
        pDialog = new SweetAlertDialog(SellActivity.this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#D81B60"));
        pDialog.setTitleText("Uploading ...");
        pDialog.setCancelable(false);
        pDialog.show();

    }
    public void showProgress(String title)
    {
        hud= KProgressHUD.create(SellActivity.this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel(title)
                .setCancellable(true)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f)
                .show();
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("You need to enable Location services so we can get Your Current Location")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    void uploadMultiFile(String id) {

        ApiService service = ApiClient.createService(ApiService.class);

        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.setType(MultipartBody.FORM);


        builder.addFormDataPart("pid", id);
        builder.addFormDataPart("apikey", Urls.Apikey);

        // Multiple Images
        for (int i = 0; i <uploadingfiles.size() ; i++) {
            File file = uploadingfiles.get(i);
            RequestBody requestImage = RequestBody.create(MediaType.parse("multipart/form-data"), file);
            builder.addFormDataPart("files[]", file.getName(), RequestBody.create(MediaType.parse("multipart/form-data"), file));
        }
        final MultipartBody requestBody = builder.build();
        Call<com.sarmad.bechda.Api.Response> call = service.event_store(requestBody);

        call.enqueue(new Callback<com.sarmad.bechda.Api.Response>() {
            @Override
            public void onResponse(Call<com.sarmad.bechda.Api.Response> call, retrofit2.Response<com.sarmad.bechda.Api.Response> response) {

                pDialog.dismiss();
                SweetAlertDialog  sDialog = new SweetAlertDialog(SellActivity.this, SweetAlertDialog.SUCCESS_TYPE);
                sDialog.getProgressHelper().setBarColor(Color.parseColor("#D81B60"));
                sDialog.setTitleText("Success")
                        .setContentText("Your Product Has been Uploaded")
                        .setConfirmText("Great")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                uploadingfiles.clear();
                                Intent i = new Intent(SellActivity.this,MainActivity.class);
                                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(i);
                            }
                        });
                sDialog.show();
                Log.i("response",response.toString());
            }
            @Override
            public void onFailure(Call<com.sarmad.bechda.Api.Response> call, Throwable t) {
                Toast.makeText(getApplicationContext(),"Failed",Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override
    public void onSingleImageSelected(Uri uri, String tag) {
        File imageFile = new File(getRealPathFromURI(uri));
        uploadingfiles.add(imageFile);
        File imagefile = new File(getRealPathFromURI(uri));
            Bitmap myBitmap = BitmapFactory.decodeFile(imagefile.getAbsolutePath());
            image1.setImageBitmap(myBitmap);
        imageFlag=1;
    }
    @Override
    public void onMultiImageSelected(List<Uri> uriList, String tag) {
        for (int i=0; i<uriList.size();i++)
        {
            File imagefile = new File(getRealPathFromURI(uriList.get(i)));
                if (i==0)
                {
                    Bitmap myBitmap = BitmapFactory.decodeFile(imagefile.getAbsolutePath());
                    image1.setImageBitmap(myBitmap);
                    imageFlag=1;
                }
                else if(i==1) {
                    Bitmap myBitmap = BitmapFactory.decodeFile(imagefile.getAbsolutePath());
                    image2.setImageBitmap(myBitmap);

                }
                else if (i==2)
                {
                    Bitmap myBitmap = BitmapFactory.decodeFile(imagefile.getAbsolutePath());
                    image3.setImageBitmap(myBitmap);
                }
                imageCounter.setText(i+" images selected ");
                selectedImgaes++;
                File imageFile = new File(getRealPathFromURI(uriList.get(i)));
                uploadingfiles.add(imageFile);
        }
    }
    @Override
    public void loadImage(File imageFile, ImageView ivImage) {
        //Glide is just an example. You can use any image loading library you want;
        //This callback is to make sure the library has the flexibility to allow user to choose their own image loading method.
        Glide.with(SellActivity.this).load(imageFile).into(ivImage);
    }
    private String getRealPathFromURI(Uri contentURI) {
        String result;
        Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }
    private void checkPermissions() {
        Dexter.withActivity(this)
                .withPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new PermissionListener() {
                    @Override public void onPermissionGranted(PermissionGrantedResponse response) {/* ... */}
                    @Override public void onPermissionDenied(PermissionDeniedResponse response) {/* ... */}
                    @Override public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {/* ... */}
                }).check();
        Dexter.withActivity(this)
                .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new PermissionListener() {
                    @Override public void onPermissionGranted(PermissionGrantedResponse response) {/* ... */}
                    @Override public void onPermissionDenied(PermissionDeniedResponse response) {/* ... */}
                    @Override public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {/* ... */}
                }).check();

    }
    private void pickimage()
    {
        Boolean result = checkGalleryPermssion();
        if (result) {
            if (mPaths.size()>0)
            {
                mPaths.clear();
            }
            new ImagePicker.Builder(SellActivity.this)
                    .mode(ImagePicker.Mode.CAMERA_AND_GALLERY)
                    .compressLevel(ImagePicker.ComperesLevel.MEDIUM)
                    .directory(ImagePicker.Directory.DEFAULT)
                    .extension(ImagePicker.Extension.JPG)
                    .scale(600, 600)
                    .allowMultipleImages(true)
                    .enableDebuggingMode(true)
                    .build();
        } else {
            Toast.makeText(getApplicationContext(), " Permission to access Gallery", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (imageFlag >=1)
        {
            chooseImage.setText(" Add More ");
        }
        if (requestCode == ImagePicker.IMAGE_PICKER_REQUEST_CODE && resultCode == RESULT_OK) {
            List<String> mPaths = data.getStringArrayListExtra(ImagePicker.EXTRA_IMAGE_PATH);

            for (int i=0; i<mPaths.size();i++)
            {
                imageFlag=1;
                File imagefile = new File( mPaths.get(i));
                uploadingfiles.add(imagefile);

            }

            for (int j= 0 ; j<uploadingfiles.size();j++)
            {
                File file = uploadingfiles.get(j);
                if (j==0)
                {
                    Bitmap myBitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                    image1.setImageBitmap(myBitmap);

                }
                else if(j==1) {
                    Bitmap myBitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                    image2.setImageBitmap(myBitmap);
                }
                else if (j==2)
                {
                    Bitmap myBitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                    image3.setImageBitmap(myBitmap);
                }

            }
            selectedImgaes++;
            imageCounter.setText(uploadingfiles.size()+" images selected ");

        }
    }

    public Boolean checkGalleryPermssion()
    {
        Dexter.withActivity(SellActivity.this)
                .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse response) {
                        galleryCheck=1;
                    }
                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse response) {
                        galleryCheck=0;
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();

        if (galleryCheck==0)
        {
            return false;
        }
        else  if (galleryCheck==1)
        {
            return true;
        }
        return null;
    }
}

