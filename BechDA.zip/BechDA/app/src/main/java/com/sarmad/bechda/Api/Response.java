package com.sarmad.bechda.Api;

public class Response{
    private String error;
    private String message;
    //getters and setters
}