package com.sarmad.bechda.myPosts;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.sarmad.bechda.R;
import com.sarmad.bechda.explore.DetailsModel;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.MyViewHolder>  {

    private LayoutInflater inflater;
    private ArrayList<PostModel> dataModelArrayList;
    private Context mcontext;
    private PostAdapter.OnItemClickListner mlistener;

    public interface OnItemClickListner
    {

        void onItemClicked(int position);
    }

    public void setOnItemClickListner(PostAdapter.OnItemClickListner listener)
    {
        mlistener= listener;
    }

    public PostAdapter(Context ctx, ArrayList<PostModel> dataModelArrayList){

        mcontext=ctx;
        inflater = LayoutInflater.from(ctx);
        this.dataModelArrayList = dataModelArrayList;
    }

    @Override
    public PostAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = inflater.inflate(R.layout.card_my_posts, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(PostAdapter.MyViewHolder holder, int position) {

        holder.name.setText( dataModelArrayList.get(position).getName());
        holder.price.setText("RS "+dataModelArrayList.get(position).getPrice());
        holder.location.setText(dataModelArrayList.get(position).getLocation());
        Picasso.get().load(dataModelArrayList.get(position).getTitleImaage()).into(holder.image);
    }

    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView  name, price,location;
        ImageView image,delete;
        Spinner locationspinner;

        public MyViewHolder(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.name);
            price = itemView.findViewById(R.id.price);
            location = itemView.findViewById(R.id.location);
            image=  itemView.findViewById(R.id.thumbnail);

            delete=  itemView.findViewById(R.id.del);
            locationspinner= itemView.findViewById(R.id.product_location);

            delete.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if(pos != RecyclerView.NO_POSITION){
                        if(mlistener!=null)
                        {
                            int position= getAdapterPosition();
                            if(position!= RecyclerView.NO_POSITION){
                                mlistener.onItemClicked(position);
                            }
                        }

                    }
                }
            });
        }

    }

}

