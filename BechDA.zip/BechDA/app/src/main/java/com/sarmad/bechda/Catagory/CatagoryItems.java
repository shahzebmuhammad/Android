package com.sarmad.bechda.Catagory;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.sarmad.bechda.R;
import com.sarmad.bechda.explore.BuyAdapter;
import com.sarmad.bechda.explore.DetailsModel;
import com.sarmad.bechda.explore.ImageModel;
import com.sarmad.bechda.explore.productDetails;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.sarmad.bechda.Api.Urls.Apikey;
import static com.sarmad.bechda.Api.Urls.getProducts;
import static com.sarmad.bechda.Api.Urls.serachByName;
import static com.sarmad.bechda.Api.Urls.serachByType;

public class CatagoryItems extends AppCompatActivity {

    ArrayList<DetailsModel> dataModelArrayList;
    ArrayList<ImageModel> ImageModelArrayList;
    private BuyAdapter rvAdapter;
    private Context mcontext;
    private RequestQueue queue;
    private RecyclerView shimmerRecycler;
    private RelativeLayout ProgressLayout;
    private ShimmerFrameLayout mcontainer;
    private LinearLayout no_item;
    private ImageView btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catagroy_items);
        mcontext = getApplicationContext();
        initilizateLayouts();
        fetchMainCatagories(getType());
    }

    private void fetchMainCatagories(final String mType) {
        StringRequest postRequest = new StringRequest(Request.Method.POST, serachByType,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        hideProgress();
                        Log.d("Response", response);
                        try {
                            dataModelArrayList = new ArrayList<>();
                            ImageModelArrayList = new ArrayList<>();
                            dataModelArrayList.clear();
                            dataModelArrayList.clear();
                            JSONArray jArray = new JSONArray(response);

                            for (int i = 0; i < jArray.length(); i++) {
                                JSONObject json_obj = jArray.getJSONObject(i);
                                if (json_obj.getString("status").equals("error")) {
                                    no_item.setVisibility(View.VISIBLE);
                                    ProgressLayout.setVisibility(View.GONE);
                                } else {
                                    no_item.setVisibility(View.GONE);
                                    DetailsModel CatgoriesModal = new DetailsModel();
                                    CatgoriesModal.setId(json_obj.getString("id"));
                                    CatgoriesModal.setName(json_obj.getString("name"));
                                    CatgoriesModal.setPrice(json_obj.getString("price"));
                                    CatgoriesModal.setLocation(json_obj.getString("location"));
                                    CatgoriesModal.setType(json_obj.getString("type"));
                                    CatgoriesModal.setProductDescription(json_obj.getString("description"));
                                    CatgoriesModal.setUsername(json_obj.getString("username"));
                                    CatgoriesModal.setUserphone(json_obj.getString("userphone"));
                                    CatgoriesModal.setTitleImaage("http://biztechengg.com/sarmad/Api/" + json_obj.getString("Image_urls"));
                                    dataModelArrayList.add(CatgoriesModal);
                                }
                            }
                            setupRecycler();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(mcontext, "Internet Connection Error", Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("apikey", Apikey);
                params.put("type", mType);
                return params;
            }
        };
        queue.add(postRequest);
    }

    private void setupRecycler() {
        rvAdapter = new BuyAdapter(mcontext, dataModelArrayList);
        shimmerRecycler.setAdapter(rvAdapter);
        shimmerRecycler.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        rvAdapter.notifyDataSetChanged();
        rvAdapter.setOnItemClickListner(new BuyAdapter.OnItemClickListner() {
            @Override
            public void onItemClicked(int position) {
                DetailsModel clickedDataItem = dataModelArrayList.get(position);
                Intent productdetail = new Intent(CatagoryItems.this, productDetails.class);
                productdetail.putExtra("p_id", clickedDataItem.getId());
                productdetail.putExtra("user_name", clickedDataItem.getUsername());
                productdetail.putExtra("name", clickedDataItem.getName());
                productdetail.putExtra("price", clickedDataItem.getPrice());
                productdetail.putExtra("location", clickedDataItem.getLocation());
                productdetail.putExtra("user_phone", clickedDataItem.getUserphone());
                productdetail.putExtra("detail", clickedDataItem.getProductDescription());
                productdetail.putExtra("type", clickedDataItem.getType());
                startActivity(productdetail);
            }
        });
    }

    private void hideProgress() {
        ProgressLayout = findViewById(R.id.shimmer_layout);
        ProgressLayout.setVisibility(View.GONE);
        mcontainer.stopShimmerAnimation();
    }

    private void showProgress() {
        ProgressLayout = findViewById(R.id.shimmer_layout);
        ProgressLayout.setVisibility(View.VISIBLE);
        mcontainer.startLayoutAnimation();
    }

    private void initilizateLayouts() {

        mcontainer = findViewById(R.id.parentShimmerLayout);
        no_item = findViewById(R.id.no_item);
        btnBack = findViewById(R.id.btn_back);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        showProgress();
        queue = Volley.newRequestQueue(mcontext);
        shimmerRecycler = findViewById(R.id.shimmer_recycler_view);
    }

    private String getType()
    {
        Intent intent = getIntent();
        String type = intent.getStringExtra("type");
        return type;
    }
}