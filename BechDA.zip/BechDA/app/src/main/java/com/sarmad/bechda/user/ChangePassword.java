package com.sarmad.bechda.user;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.sarmad.bechda.Api.Urls;
import com.sarmad.bechda.MainActivity;
import com.sarmad.bechda.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChangePassword extends AppCompatActivity {

    EditText editpassord , newpassword, phoneNumber;
    String uid;
    private String customerId,newsletter;
    RequestQueue queue;
    KProgressHUD hud;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        queue = Volley.newRequestQueue(this);
        editpassord = findViewById(R.id.password);
        newpassword = findViewById(R.id.confirm_password);

        SharedPreferences loginPref = getApplicationContext().getSharedPreferences("loginPref", 0); // 0 - for private mode
        final Boolean islogged = loginPref.getBoolean("status",false);
        String sname =  loginPref.getString("name",null);
        String semail = loginPref.getString("email",null);
        String sphone = loginPref.getString("phone",null);
        customerId = loginPref.getString("id",null);
        newsletter = loginPref.getString("newsletter",null);
        Button changepassword = findViewById(R.id.passwordupdatebtn);
        changepassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (newpassword.getText().toString().length() < 8 || !(isValidPassword(newpassword.getText().toString()))) {
                    newpassword.setError("Password must contain at least 8 characters! One special characters. !@#$%^&*)");
                    newpassword.requestFocus();
                    return;
                }
                else{ makeUpdate(editpassord.getText().toString(),newpassword.getText().toString()); }

            }
        });

        ImageView back_button = findViewById(R.id.btn_back);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }



    public void makeUpdate(final String password, final String newpassword)
    {
        SharedPreferences pref = getApplicationContext().getSharedPreferences("loginPref", 0); // 0 - for private mode
        editor = pref.edit();

        StringRequest postRequest = new StringRequest(Request.Method.POST, Urls.updatePasswoord,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        hideProgress();
                        Log.i("resper",response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String responsestatus = jsonObject.getString("status");

                            if(responsestatus.equals("success")) {

                                String status = jsonObject.getString("data");
                                if(status.equals("wrong_password"))
                                {
                                    editpassord.setError("Invalid Current password");
                                }
                                else if(status.equals("updated"))
                                {
                                    AlertDialog alertDialog = new AlertDialog.Builder(ChangePassword.this).create();
                                    alertDialog.setTitle("Updated");
                                    alertDialog.setMessage("your Password is now updated");
                                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    editor.putString("name","");
                                                    editor.putString("email","");
                                                    editor.putString("phone","");
                                                    editor.putString("id","");
                                                    editor.putBoolean("status",false);
                                                    editor.apply();

                                                    Intent intent = new Intent(ChangePassword.this, MainActivity.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                    startActivity(intent);
                                                }
                                            });
                                    alertDialog.show();
                                }

                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(),response.toString(),Toast.LENGTH_SHORT).show();
                            }
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        hideProgress();

                        Toast.makeText(getApplicationContext(),"Something went wrong try again",Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("old_password", password);
                params.put("apikey", Urls.Apikey);
                params.put("new_password", newpassword);
                params.put("id", customerId);
                return params;
            }
        };
        queue.add(postRequest);
        showProgress();
    }

    public void showProgress()
    {
        hud= KProgressHUD.create(ChangePassword.this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Updating")
                .setCancellable(true)
                .setAnimationSpeed(2)
                .show();
    }

    public static boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();

    }

    public void hideProgress()
    {

        hud.dismiss();
    }
}
