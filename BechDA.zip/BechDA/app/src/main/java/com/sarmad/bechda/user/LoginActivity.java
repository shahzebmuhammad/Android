package com.sarmad.bechda.user;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.google.android.material.textfield.TextInputLayout;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.sarmad.bechda.MainActivity;
import com.sarmad.bechda.R;
import com.sarmad.bechda.passwords.ForgetPassword;
import com.sarmad.bechda.sell.SellActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.sarmad.bechda.Api.Urls.Apikey;
import static com.sarmad.bechda.Api.Urls.login;


public class
LoginActivity extends AppCompatActivity {

    private EditText mEmailView;
    private EditText mPasswordView;
    private String email, password;
    private RequestQueue queue;
    private ImageView close_btn;
    private SharedPreferences.Editor editor;
    private KProgressHUD hud;
    private TextView errortxt;
    private TextInputLayout email_wrapper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initializeLayouts();
    }

    private void attemptLogin() {
        // Reset errors.
        mEmailView.setError(null);
        mPasswordView.setError(null);

        // Store values at the time of the login attempt.
         email = mEmailView.getText().toString();
         password = mPasswordView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid password, if the user entered one.
        if (!TextUtils.isEmpty(password) && !isPasswordValid(password)) {
            mPasswordView.setError(getString(R.string.error_password));
            focusView = mPasswordView;
            cancel = true;
        }

        if (TextUtils.isEmpty(email)) {
            mEmailView.setError(getString(R.string.error_email));
            focusView = mEmailView;
            cancel = true;
        } else if (!isEmailValid(email)) {
            mEmailView.setError(getString(R.string.error_email));
            focusView = mEmailView;
            cancel = true;
        }
        if (cancel) {
            focusView.requestFocus();
        } else {

            AttemptLogin();
        }

        }

    private boolean isEmailValid(String email) {
        //TODO: Replace this with your own logic
        return email.contains("@");
    }

    private boolean isPasswordValid(String password) {
        //TODO: Replace this with your own logic
        return password.length() >= 4;
    }

    public void AttemptLogin()
    {
        StringRequest postRequest = new StringRequest(Request.Method.POST, login,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.i("resper",response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String responsestatus = jsonObject.getString("status");
                            if(!responsestatus.isEmpty() && responsestatus.equals("invalid Credentials"))
                            {
                                mEmailView.requestFocus();
                                mPasswordView.requestFocus();
                                errortxt.setVisibility(View.VISIBLE);
                                hideProgress();
                            }

                            else if(responsestatus.equals("success")) {

                                JSONArray parentJsonArray = jsonObject.getJSONArray("response");
                                for (int i = 0; i < parentJsonArray.length(); i++) {
                                    JSONObject childJsonObject = (JSONObject) parentJsonArray.get(i);

                                    String name = childJsonObject.getString("name");
                                    String email = childJsonObject.getString("email");
                                    String phone = childJsonObject.getString("phone");
                                    String id = childJsonObject.getString("id");

                                    editor.putString("name",name);
                                    editor.putString("email",email);
                                    editor.putString("phone",phone);
                                    editor.putString("id",id);
                                    editor.putBoolean("status",true);
                                    editor.apply();
                                    hideProgress();

                                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent);

                                }
                            }
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(),"Something went wrong try again",Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("apikey",Apikey);
                params.put("email",email);
                params.put("password",password);
                return params;
            }
        };

        queue.add(postRequest);
        showProgress();
    }

    public void showProgress()
    {
        hud= KProgressHUD.create(LoginActivity.this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Please wait")
                .setCancellable(true)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f)
                .show();
    }

    public void hideProgress()
    {
        hud.dismiss();
    }

    public void callregister(View view) {

        Intent intent = new Intent(this, Register.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    public void forgetpassword(View view) {
        Intent intent = new Intent(LoginActivity.this, ForgetPassword.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        super.onBackPressed();
        Animatoo.animateSlideDown(this);
    }

    private  void  initializeLayouts()
    {
        mEmailView =  findViewById(R.id.email);
        close_btn = findViewById(R.id.btn_close);
        mPasswordView = (EditText) findViewById(R.id.password);
        errortxt = findViewById(R.id.texterror);
        queue = Volley.newRequestQueue(this);
        mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == EditorInfo.IME_ACTION_DONE || id == EditorInfo.IME_NULL) {
                    attemptLogin();
                    return true;
                }
                return false;
            }
        });

        SharedPreferences pref = getApplicationContext().getSharedPreferences("loginPref", 0); // 0 - for private mode
        editor = pref.edit();

        mEmailView.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
                errortxt.setVisibility(View.GONE);
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });
        mPasswordView.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {

                errortxt.setVisibility(View.GONE);
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });

        Button mEmailSignInButton = (Button) findViewById(R.id.email_sign_in_button);
        mEmailSignInButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptLogin();
            }
        });
        close_btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}

