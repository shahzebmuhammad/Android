package com.sarmad.bechda.user;

import android.content.Intent;
import android.os.Bundle;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.sarmad.bechda.MainActivity;
import com.sarmad.bechda.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.sarmad.bechda.Api.Urls.Apikey;
import static com.sarmad.bechda.Api.Urls.validateUser;


public class Register extends AppCompatActivity {

    private RequestQueue queue;
    private KProgressHUD hud;
    private String username ;
    private String userpassword ;
    private String userconfirmpassword ;
    private String useremail;
    private String userphone;
    private EditText edditemail;
    private EditText edditname;
    private EditText edditpassword;
    private EditText edditConfirmpassword;
    private EditText edditphone_number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
          setContentView(R.layout.activity_signup);
         initializeLayouts();
    }
    public void trigerRegister(View view) {

        username = edditname.getText().toString();
        useremail = edditemail.getText().toString();
        userpassword = edditpassword.getText().toString();
        userconfirmpassword = edditConfirmpassword.getText().toString();
        userphone = edditphone_number.getText().toString();


        if(TextUtils.isEmpty(username) || username.length()<3) {

            edditname.setError("Provide a valid name ");
            edditname.requestFocus();
            return;
        }
        else if(TextUtils.isEmpty(useremail) || !(useremail.toString().contains("@"))) {
            edditemail.setError("Provide a Valid Email Address");
            edditemail.requestFocus();
            return;
        }

        if (userpassword.length() < 8 || !(isValidPassword(userpassword))) {
                edditpassword.setError("Password must contain at least 8 characters!)");
                edditpassword.requestFocus();
                return;
        }

         if (!(userpassword.equals(userconfirmpassword))){
            edditConfirmpassword.setError("Password don't match");
            edditConfirmpassword.requestFocus();
            return;
        }
        if ((userphone.equals("")|| userphone.toString().length()>13||userphone.toString().length()<13)||!(userphone.startsWith("+92"))){
            edditphone_number.setError("invalid Phone number");
            edditphone_number.requestFocus();
        }
        else
        {
            checkUser();
        }
    }

    protected void registerUser() {
        Intent intent = new Intent(Register.this, VerifyPhone.class);
        intent.putExtra("userphone", userphone);
        intent.putExtra("username", username);
        intent.putExtra("useremail", useremail);
        intent.putExtra("userpasseord", userpassword);
        startActivity(intent);
    }

    public static boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();

    }

    public void checkUser()
    {
        StringRequest postRequest = new StringRequest(Request.Method.POST, validateUser,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            String responsestatus = jsonObject.getString("status");
                            Log.i("resp",responsestatus);


                            if(!responsestatus.isEmpty() && responsestatus.equals("ok")) {

                                registerUser();

                            }
                            else if(responsestatus.equals("phone_exists")) {

                                edditphone_number.setError("Phone Number already registered");
                                edditphone_number.requestFocus();
                            }
                            else if(responsestatus.equals("email_exits")){

                                edditemail.setError("Email already registered");
                                edditemail.requestFocus();
                            }
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                        hideProgress();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        hideProgress();
                        Toast.makeText(getApplicationContext(),"Something went wrong try again",Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("apikey",Apikey);
                params.put("email", useremail);
                params.put("phone", userphone);
                return params;
            }
        };
        queue.add(postRequest);
        showProgress();
    }

    public void showProgress()
    {
       hud= KProgressHUD.create(Register.this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Please Wait")
                .setCancellable(true)
                .setAnimationSpeed(2)
                .setDimAmount(0.5f)
                .show();
    }
    public void hideProgress()
    {
        hud.dismiss();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
    public void callLogin(View view) {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    public void  initializeLayouts()
    {
        queue = Volley.newRequestQueue(this);
        edditemail = findViewById(R.id.email);
        edditname = findViewById(R.id.name);
        edditpassword = findViewById(R.id.password);
        edditConfirmpassword = findViewById(R.id.confirm_password);
        edditphone_number = findViewById(R.id.phone_number);
        final String prefix = "+92";
        edditphone_number.setText(prefix);
    }
}