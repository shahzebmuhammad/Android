package com.sarmad.bechda.Catagory;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.sarmad.bechda.R;

public class AllCatagories extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_catagories);
        attachDetailClickListener();
    }

    public void attachDetailClickListener()
    {
        ImageView backButton = findViewById(R.id.btn_back);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        CardView item_mobiles = findViewById(R.id.card_mobile);

        item_mobiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","mobile");
                startActivity(i);
            }
        });


        CardView card_vehicles = findViewById(R.id.card_vehicles);
        card_vehicles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","Vehicles");
                startActivity(i);
            }
        });

        CardView card_bikes = findViewById(R.id.card_bikes);
        card_bikes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","Bikes");
                startActivity(i);
            }
        });

        CardView card_property = findViewById(R.id.card_property);
        card_property.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","Property for Sale");
                startActivity(i);
            }
        });

        CardView card_electronics = findViewById(R.id.card_electronics);
        card_electronics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","Electronics");
                startActivity(i);
            }
        });

        CardView card_services = findViewById(R.id.card_services);
        card_services.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","Services");
                startActivity(i);
            }
        });

        CardView card_jobs = findViewById(R.id.card_jobs);
        card_jobs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","Jobs");
                startActivity(i);
            }
        });

        CardView card_animals = findViewById(R.id.card_animals);
        card_animals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","Animals");
                startActivity(i);
            }
        });

        CardView card_furniture = findViewById(R.id.card_furniture);
        card_furniture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","Furniture and Home Decor");
                startActivity(i);
            }
        });

        CardView card_kids = findViewById(R.id.card_kids);
        card_kids.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","Kids And Fashion");
                startActivity(i);
            }
        });

        CardView card_sports = findViewById(R.id.card_sports);
        card_sports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","Books , Sports, Hobbies");
                startActivity(i);
            }
        });

        CardView card_other = findViewById(R.id.card_other);
        card_other.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), CatagoryItems.class);
                i.putExtra("type","other");
                startActivity(i);
            }
        });

    }
}
