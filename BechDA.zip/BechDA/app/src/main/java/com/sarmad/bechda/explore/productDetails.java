package com.sarmad.bechda.explore;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.sarmad.bechda.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import me.relex.circleindicator.CircleIndicator;

import static com.sarmad.bechda.Api.Urls.Apikey;
import static com.sarmad.bechda.Api.Urls.getProducts;
import static com.sarmad.bechda.Api.Urls.getproductDetails;

public class productDetails extends AppCompatActivity {

    ArrayList<ImageModel> ImageModelArrayList;
    private RequestQueue queue;
    private String productID,name,username,phone,discription,type,price,location;
    private TextView txtname,txtprice,txtlocation,txtusername,txtphone,txtdiscription,txttype;
    private Button callButton, smsButton;
    ImageView share;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        getIntentDeatil();
        intilizeLayout();
        registerButtons();
        fetchImages();
    }
    public  void fetchImages( ) {
        StringRequest postRequest = new StringRequest(Request.Method.POST, getproductDetails,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("Response", response);
                        hideProgress();
                        try {
                            ImageModelArrayList = new ArrayList<>();

                            JSONArray jArray = new JSONArray(response);

                            for (int i = 0; i < jArray.length(); i++) {
                                JSONObject json_obj = jArray.getJSONObject(i);
                                ImageModel CatgoriesModal = new ImageModel();
                                CatgoriesModal.setImageurl("http://biztechengg.com/sarmad/Api/"+json_obj.getString("ImageUrl"));
                                ImageModelArrayList.add(CatgoriesModal);
                            }
                            setupimagePager();
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Something went wrong try again", Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("apikey", Apikey);
                params.put("id", productID);

                return params;
            }
        };
        queue.add(postRequest);
        showprogress();
    }
    private void setupimagePager()
    {
        ViewPager viewPager = findViewById(R.id.view_pager);
        ImageAdapter adapter = new ImageAdapter(this, ImageModelArrayList);
        viewPager.setAdapter(adapter);
        CircleIndicator indicator = (CircleIndicator) findViewById(R.id.indicator);
        indicator.setViewPager(viewPager);
    }
    public  void showprogress()
    {
        progressBar.setVisibility(View.VISIBLE);
    }
    public  void hideProgress()
    {
        progressBar.setVisibility(View.GONE);
    }
    private void getIntentDeatil()
    {
        Intent productintent = getIntent();

        productID=  productintent.getStringExtra("p_id");
        username=  productintent.getStringExtra("user_name");

        name=  productintent.getStringExtra("name");
        price=  productintent.getStringExtra("price");
        location=  productintent.getStringExtra("location");

        phone=  productintent.getStringExtra("user_phone");
        discription=  productintent.getStringExtra("detail");
        type=  productintent.getStringExtra("type");
    }
    private  void intilizeLayout()
    {
        txtname= findViewById(R.id.name);
        txtprice= findViewById(R.id.price);
        txtlocation= findViewById(R.id.location);
        txtdiscription= findViewById(R.id.details);
        txttype= findViewById(R.id.type);
        progressBar= findViewById(R.id.progressBar);
        share = findViewById(R.id.share);
        txtname.setText(name);
        txtlocation.setText("City : "+location);
        txtprice.setText("Rs : "+price);
        txtdiscription.setText(discription);
        txttype.setText(type);
        callButton= findViewById(R.id.btn_calll);
        smsButton= findViewById(R.id.btn_sms);
        queue = Volley.newRequestQueue(getApplicationContext());
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,"Hello Dear I found this on baich Dy "+ name +" in City "+ location+ " Find it here:   https://play.google.com/store/apps/details?id=com.sarmad.bechda");
                sendIntent.setType("text/html");
                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
            }
        });
    }
    private  void registerButtons()
    {
        callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phone = phone.replace(")", "");
                phone = phone.replace("(", "");
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null));
                startActivity(intent);
            }
        });

        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("sms:"+ phone);
                Intent it = new Intent(Intent.ACTION_SENDTO, uri);
                it.putExtra("sms_body", "Hello Dear i am interested in your product  : "+name+" i Would Like to know.." );
                startActivity(it);
            }
        });
    }
}
