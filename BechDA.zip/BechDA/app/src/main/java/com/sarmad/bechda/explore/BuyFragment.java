package com.sarmad.bechda.explore;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.sarmad.bechda.Catagory.AllCatagories;
import com.sarmad.bechda.Catagory.CatagoryItems;
import com.sarmad.bechda.R;
import com.sarmad.bechda.search.MSearchActivity;
import com.sarmad.bechda.sell.SellActivity;
import com.sarmad.bechda.user.LoginActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;
import static com.sarmad.bechda.Api.Urls.Apikey;
import static com.sarmad.bechda.Api.Urls.getProducts;


public class BuyFragment extends Fragment {
    private View rootview;
    public ArrayList<DetailsModel> dataModelArrayList;
    public ArrayList<ImageModel> ImageModelArrayList;
    private BuyAdapter rvAdapter;
    private Context mcontext;
    private RequestQueue queue;
    private FloatingActionButton sellBtton;
    private RecyclerView shimmerRecycler;
    private RelativeLayout ProgressLayout;
    private ShimmerFrameLayout mcontainer;
    private Spinner locationspinner;
    private TextView search_view;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private Double lat;
    private Double lng;
    private int locationCheck;
    private String globalCity;
    private TextView locationText;
    private ImageView changeLocation;
    private int AUTOCOMPLETE_REQUEST_CODE = 1;
    private ProgressDialog dialog;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) { rootview = inflater.inflate(R.layout.fragment_buy, container, false);
        mcontext = container.getContext();
        mcontainer = rootview.findViewById(R.id.parentShimmerLayout);
        initializeLayouts();
        fetchProductsList();
        return rootview;
    }
    /*Fetch Products from online database using volley and Add all the products to list */
    public  void fetchProductsList( ) {
        StringRequest postRequest = new StringRequest(Request.Method.POST, getProducts,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        hideProgress();
                        Log.d("Response", response);
                        try {
                            dataModelArrayList = new ArrayList<>();
                            ImageModelArrayList = new ArrayList<>();

                                JSONArray jArray = new JSONArray(response);

                                for (int i = 0; i < jArray.length(); i++) {
                                JSONObject json_obj = jArray.getJSONObject(i);
                                DetailsModel CatgoriesModal = new DetailsModel();
                                CatgoriesModal.setId(json_obj.getString("id"));
                                CatgoriesModal.setName(json_obj.getString("name"));
                                CatgoriesModal.setPrice(json_obj.getString("price"));
                                CatgoriesModal.setLocation(json_obj.getString("location"));
                                CatgoriesModal.setType(json_obj.getString("type"));
                                CatgoriesModal.setProductDescription(json_obj.getString("description"));
                                CatgoriesModal.setUsername(json_obj.getString("username"));
                                CatgoriesModal.setUserphone(json_obj.getString("userphone"));
                                CatgoriesModal.setTitleImaage("http://biztechengg.com/sarmad/Api/"+json_obj.getString("Image_urls"));
                                dataModelArrayList.add(CatgoriesModal);
                                }
                                setupRecycler();
                                }
                              catch (JSONException e)
                              {
                                e.printStackTrace();
                                }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(mcontext, "Internet Connection Error", Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("apikey", Apikey);
                return params;
            }
        };
        queue.add(postRequest);
    }
    /* Retrieve the products from the array list and setup it on RecyclerView */
    private void setupRecycler() {
        rvAdapter = new BuyAdapter(mcontext, dataModelArrayList);
        shimmerRecycler.setAdapter(rvAdapter);
        shimmerRecycler.setLayoutManager(new GridLayoutManager(getContext(), 2));

        rvAdapter.setOnItemClickListner(new BuyAdapter.OnItemClickListner() {
            @Override
            public void onItemClicked(int position) {
                DetailsModel clickedDataItem = dataModelArrayList.get(position);
                Intent productdetail = new Intent(mcontext,productDetails.class);
                productdetail.putExtra("p_id",clickedDataItem.getId());
                productdetail.putExtra("user_name",clickedDataItem.getUsername());
                productdetail.putExtra("name",clickedDataItem.getName());
                productdetail.putExtra("price",clickedDataItem.getPrice());
                productdetail.putExtra("location",clickedDataItem.getLocation());
                productdetail.putExtra("user_phone",clickedDataItem.getUserphone());
                productdetail.putExtra("detail",clickedDataItem.getProductDescription());
                productdetail.putExtra("type",clickedDataItem.getType());
                startActivity(productdetail);
            }
        });
        attachFilter();
        SharedPreferences prefs = mcontext.getSharedPreferences("location_pref", MODE_PRIVATE);
        String location = prefs.getString("lastlocation", "");
        if (!location.equals(""))
        {
            attachLocationFilter(location);
            locationText.setText(location);
        }
    }

    private  void attachClick()
    {
        sellBtton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isUserLoggedIn()) {
                    Intent sellIntent = new Intent(mcontext, SellActivity.class);
                    startActivity(sellIntent);
                }
                else
                {
                    Intent sellIntent = new Intent(mcontext, LoginActivity.class);
                    startActivity(sellIntent);
                }
            }
        });

        changeLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final LocationManager manager = (LocationManager) mcontext.getSystemService(Context.LOCATION_SERVICE);

                if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    buildAlertMessageNoGps();
                }
                else {
                    getUserLocation();
                }

            }
        });

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == AUTOCOMPLETE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Place place = Autocomplete.getPlaceFromIntent(data);
                Log.i("place ", "Place: " + place.getName() + ", " + place.getId());
            } else if (resultCode == AutocompleteActivity.RESULT_ERROR) {
                // TODO: Handle the error.
                Status status = Autocomplete.getStatusFromIntent(data);
                Log.i("place ", status.getStatusMessage());
            } else if (resultCode == RESULT_CANCELED) {
                // The user canceled the operation.
            }
        }
    }

    private void hideProgress()
    {
        ProgressLayout = rootview.findViewById(R.id.shimmer_layout);
        ProgressLayout.setVisibility(View.GONE);
        mcontainer.stopShimmerAnimation();
        locationspinner.setVisibility(View.VISIBLE);
    }

    private void showProgress()
    {
        ProgressLayout = rootview.findViewById(R.id.shimmer_layout);
        ProgressLayout.setVisibility(View.VISIBLE);
        mcontainer.startLayoutAnimation();
    }
    private void attachFilter(){

        locationspinner.setSelected(true);
        locationspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if (i > 0) {
                    // Notify the selected item text
                    String msupplier = locationspinner.getSelectedItem().toString();
                    locationText.setText(msupplier);
                    SharedPreferences.Editor editor = mcontext.getSharedPreferences("location_pref", MODE_PRIVATE).edit();
                    editor.putString("lastlocation", msupplier);
                    editor.apply();
                    SharedPreferences prefs = mcontext.getSharedPreferences("location_pref", MODE_PRIVATE);
                    String location = prefs.getString("lastlocation", "");
                    rvAdapter.getFilter().filter(msupplier);
                }
                else {
                    TextView tv = (TextView) view;
                    if (i == 0) {
                        // Set the hint text color gray
                        tv.setTextColor(Color.GRAY);}
                    else {
                        tv.setTextColor(Color.BLACK);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                SharedPreferences prefs = mcontext.getSharedPreferences("location_pref", MODE_PRIVATE);
                String location = prefs.getString("lastlocation", "");
                locationText.setText(location);
                if (!location.equals(""))
                {
                    attachLocationFilter(location);
                }
            }
        });

    }

    private void attachLocationFilter(String city){

        rvAdapter.getFilter().filter(city);
    }

    private Boolean isUserLoggedIn()
    {
        SharedPreferences loginPref = mcontext.getSharedPreferences("loginPref", 0); // 0 - for private mode
        Boolean islogged = loginPref.getBoolean("status",false);
        if(islogged)
        {
            return true;
        }
        else{
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            return  false;
        }
    }

    public Boolean checkLocationPermission()
    {
        Dexter.withActivity(getActivity())
                .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                .withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse response) {
                        locationCheck=1;
                    }
                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse response) {
                        locationCheck=0;
                    }
                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).check();

        if (locationCheck==0)
        {
            return false;
        }
        else  if (locationCheck==1)
        {
            return true;
        }
        return null;
    }

    public void requestLocation()
    {
        if(Build.VERSION.SDK_INT<23)
        {
            if(ContextCompat.checkSelfPermission(mcontext, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                dialog = new ProgressDialog(mcontext);
                dialog.setMessage("Retrieving Location!");
                dialog.show();
            }
            else {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
            }
        }
        else {
            if (ContextCompat.checkSelfPermission(mcontext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {

                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);

                dialog = new ProgressDialog(mcontext);
                dialog.setMessage("Retrieving Location!");
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();

            }
        }
    }

    private void getUserLocation()
    {
        if (checkLocationPermission()) {
            locationManager = (LocationManager) mcontext.getSystemService(Context.LOCATION_SERVICE);
            locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    dialog.dismiss();
                    lat = location.getLatitude();
                    lng = location.getLongitude();
                    Log.i("laatt", lat.toString());

                    if(lat.toString().equals("") && lng.toString().equals("")) { }
                    else {

                        Geocoder geocoder = new Geocoder(mcontext, Locale.getDefault());
                        List<Address> addresses = null;
                        try {
                            addresses = geocoder.getFromLocation(lat, lng, 1);
                            String address = addresses.get(0).getSubLocality();
                            String cityName = addresses.get(0).getLocality();
                            globalCity= cityName;
                            SharedPreferences.Editor editor = mcontext.getSharedPreferences("location_pref", MODE_PRIVATE).edit();
                            editor.putString("lastlocation", cityName);
                            editor.apply();
                            attachLocationFilter(globalCity);
                            TextView txtlocation = rootview.findViewById(R.id.txtLocation);
                            txtlocation.setText(cityName.toString());
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                        }

                        //Toast.makeText(getApplicationContext(),cityName.toString(),Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) { }
                @Override
                public void onProviderEnabled(String provider) { }
                @Override
                public void onProviderDisabled(String provider) { }
            };
            requestLocation();
        }
        else
        {
            Toast.makeText(mcontext,"Please Allow App to Access Location in Settings",Toast.LENGTH_LONG).show();
        }
    }
    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(mcontext);
        builder.setMessage("You need to enable Location services so we can get Your Current Location")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    private void categoriesItemsClickEvents()
    {
        RelativeLayout item_mobiles = rootview.findViewById(R.id.item_mobiles);
        item_mobiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mcontext, CatagoryItems.class);
                i.putExtra("type","mobile");
                startActivity(i);
            }
        });

        RelativeLayout item_bikes = rootview.findViewById(R.id.item_bikes);
        item_bikes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mcontext, CatagoryItems.class);
                i.putExtra("type","Bikes");
                startActivity(i);
            }
        });

        RelativeLayout item_vehicles = rootview.findViewById(R.id.item_vehicles);
        item_vehicles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mcontext, CatagoryItems.class);
                i.putExtra("type","Vehicles");
                startActivity(i);
            }
        });

        RelativeLayout item_property = rootview.findViewById(R.id.item_property);
        item_property.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mcontext, CatagoryItems.class);
                i.putExtra("type","Property");
                startActivity(i);
            }
        });

        RelativeLayout item_electronics = rootview.findViewById(R.id.item_electronics);
        item_electronics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mcontext, CatagoryItems.class);
                i.putExtra("type","Electronics");
                startActivity(i);
            }
        });
        RelativeLayout item_services = rootview.findViewById(R.id.item_services);
        item_services.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mcontext, CatagoryItems.class);
                i.putExtra("type","Services");
                startActivity(i);
            }
        });

        TextView seeAll = rootview.findViewById(R.id.text_seeAll);
        seeAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mcontext, AllCatagories.class);
                startActivity(i);
            }
        });
    }
    private void initializeLayouts()
    {
        showProgress();
        queue = Volley.newRequestQueue(mcontext);
        shimmerRecycler = rootview.findViewById(R.id.shimmer_recycler_view);
        sellBtton = rootview.findViewById(R.id.btn_sell);
        locationText = rootview.findViewById(R.id.txtLocation);
        changeLocation = rootview.findViewById(R.id.currentLocation);
        attachClick();
        locationspinner= rootview.findViewById(R.id.product_location);
        search_view = rootview.findViewById(R.id.search_view);
        search_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mcontext, MSearchActivity.class);
                startActivity(i);
            }
        });
        if (!Places.isInitialized()) { Places.initialize(mcontext, getString(R.string.api_key)); }
        categoriesItemsClickEvents();
    }

}