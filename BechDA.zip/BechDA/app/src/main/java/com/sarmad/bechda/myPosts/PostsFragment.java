package com.sarmad.bechda.myPosts;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.kaopiz.kprogresshud.KProgressHUD;

import com.sarmad.bechda.R;
import com.sarmad.bechda.explore.ImageModel;

import com.sarmad.bechda.user.LoginActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;

import static com.sarmad.bechda.Api.Urls.Apikey;
import static com.sarmad.bechda.Api.Urls.deleteProduct;
import static com.sarmad.bechda.Api.Urls.getProductsByID;


public class PostsFragment extends Fragment {

    View rootview;
    ArrayList<PostModel> dataModelArrayList;
    ArrayList<ImageModel> ImageModelArrayList;
    private PostAdapter rvAdapter;
    private Context mcontext;
    RequestQueue queue;
    KProgressHUD hud;
    private FloatingActionButton sellBtton;
    RecyclerView shimmerRecycler;

    public static String slected_date;
    RelativeLayout ProgressLayout;
    ShimmerFrameLayout mcontainer;
    LocationManager locationManager;
    LocationListener locationListener;
    public Double lat;
    public Double lng;
    int locationCheck;
    String globalCity;
    TextView locationText;
    ImageView changeLocation;
    private String customerId;
    private String newsletter;
    private SweetAlertDialog pDialog;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) { rootview = inflater.inflate(R.layout.fragment_my_posts, container, false);

        mcontext = container.getContext();
        mcontainer = rootview.findViewById(R.id.parentShimmerLayout);
        isUserLoggedIn();

        showProgress();
        queue = Volley.newRequestQueue(mcontext);
        shimmerRecycler = rootview.findViewById(R.id.shimmer_recycler_view);
        sellBtton = rootview.findViewById(R.id.btn_sell);
        locationText = rootview.findViewById(R.id.txtLocation);
        changeLocation = rootview.findViewById(R.id.currentLocation);

        SharedPreferences loginPref =mcontext.getSharedPreferences("loginPref", 0); // 0 - for private mode
        final Boolean islogged = loginPref.getBoolean("status",false);
        customerId = loginPref.getString("id",null);
        newsletter = loginPref.getString("newsletter",null);
        fetchMyProducts();
        return rootview;
    }

    private  void fetchMyProducts( ) {
        StringRequest postRequest = new StringRequest(Request.Method.POST, getProductsByID,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        hideProgress();
                        Log.d("Response", response);
                        try {
                                dataModelArrayList = new ArrayList<>();
                                ImageModelArrayList = new ArrayList<>();
                                JSONArray jArray = new JSONArray(response);
                                for (int i = 0; i < jArray.length(); i++) {
                                    JSONObject json_obj = jArray.getJSONObject(i);
                                    PostModel postModel = new PostModel();
                                    postModel.setId(json_obj.getString("id"));
                                    postModel.setName(json_obj.getString("name"));
                                    postModel.setPrice(json_obj.getString("price"));
                                    postModel.setLocation(json_obj.getString("location"));
                                    postModel.setType(json_obj.getString("type"));
                                    postModel.setProductDescription(json_obj.getString("description"));
                                    postModel.setUsername(json_obj.getString("username"));
                                    postModel.setUserphone(json_obj.getString("userphone"));
                                    postModel.setTitleImaage("http://biztechengg.com/sarmad/Api/" + json_obj.getString("Image_urls"));
                                    dataModelArrayList.add(postModel);
                                }
                                setupRecycler();
                           }
                             catch (JSONException e)
                              {
                                  e.printStackTrace();
                                  RelativeLayout layout = rootview.findViewById(R.id.no_item);layout.setVisibility(View.VISIBLE);
                              }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(mcontext, "Internet Connection Error", Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("apikey", Apikey);
                params.put("id", customerId);
                return params;
            }
        };
        queue.add(postRequest);
    }

    private void setupRecycler() {
        rvAdapter = new PostAdapter(mcontext, dataModelArrayList);
        shimmerRecycler.setAdapter(rvAdapter);
        shimmerRecycler.setLayoutManager(new GridLayoutManager(getContext(), 1));

        rvAdapter.setOnItemClickListner(new PostAdapter.OnItemClickListner() {
            @Override
            public void onItemClicked( int position) {
                final int pos = position;
                new SweetAlertDialog(mcontext, SweetAlertDialog.WARNING_TYPE)
                        .setTitleText("Are you sure?")
                        .setContentText("Won't be able to recover this file!")
                        .setConfirmText("Yes,delete it!")
                        .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                            @Override
                            public void onClick(SweetAlertDialog sDialog) {
                                sDialog
                                        .setTitleText("Deleted!")
                                        .setContentText("Your imaginary file has been deleted!")
                                        .setConfirmText("OK")
                                        .setConfirmClickListener(null)
                                        .changeAlertType(SweetAlertDialog.SUCCESS_TYPE);
                                      PostModel clickedDataItem = dataModelArrayList.get(pos);
                                     deleteItem( clickedDataItem.getId());
                            }
                        })
                        .show();
            }
        });

    }
    private void hideProgress()
    {
        ProgressLayout = rootview.findViewById(R.id.shimmer_layout);
        ProgressLayout.setVisibility(View.GONE);
        shimmerRecycler = rootview.findViewById(R.id.shimmer_recycler_view);
        shimmerRecycler.setVisibility(View.VISIBLE);
        mcontainer.stopShimmerAnimation();
    }
    private void showProgress()
    {
        ProgressLayout = rootview.findViewById(R.id.shimmer_layout);
        ProgressLayout.setVisibility(View.VISIBLE);
        shimmerRecycler = rootview.findViewById(R.id.shimmer_recycler_view);
        shimmerRecycler.setVisibility(View.GONE);
        mcontainer.startLayoutAnimation();

    }

    private Boolean isUserLoggedIn()
    {
        SharedPreferences loginPref = mcontext.getSharedPreferences("loginPref", 0); // 0 - for private mode
        Boolean islogged = loginPref.getBoolean("status",false);
        if(islogged)
        {
            return true;
        }
        else{
            Intent intent = new Intent(mcontext, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            Animatoo.animateSlideUp(mcontext);
            return  false;
        }
    }

    private   void deleteItem( String atem) {
        final String itemid = atem;
        StringRequest postRequest = new StringRequest(Request.Method.POST, deleteProduct,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                       fetchMyProducts();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(mcontext, "Internet Connection Error", Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("apikey", Apikey);
                params.put("product_id", itemid);
                return params;
            }
        };
        queue.add(postRequest);
        showProgress();
    }

}