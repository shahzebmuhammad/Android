package com.sarmad.bechda.user;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.sarmad.bechda.Api.Urls;
import com.sarmad.bechda.R;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class VerifyPhone extends AppCompatActivity {

    String name; String phone; String email; String password;
    private String mVerificationId;
    RelativeLayout progresslayout;
     RequestQueue queue;

    SharedPreferences.Editor editor;

    private EditText editTextCode;

    private FirebaseAuth mAuth;
     KProgressHUD hud;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_phone);
        progresslayout = findViewById(R.id.RelativeProgress);
        queue = Volley.newRequestQueue(this);

        FirebaseApp.initializeApp(VerifyPhone.this);
        mAuth = FirebaseAuth.getInstance();

        SharedPreferences pref = getApplicationContext().getSharedPreferences("loginPref", 0); // 0 - for private mode
        editor = pref.edit();
        editTextCode = findViewById(R.id.editTextCode);

        Intent intent = getIntent();
       phone= intent.getStringExtra("userphone");
        name=   intent.getStringExtra("username");
       email=  intent.getStringExtra("useremail");
       password =  intent.getStringExtra("userpasseord");

       sendVerificationCode(phone);
        showProgress();

        TextView number = findViewById(R.id.number);
        number.setText(phone);
        findViewById(R.id.buttonSignIn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = editTextCode.getText().toString().trim();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
                    if (code.isEmpty() || code.length() < 6) {
                        editTextCode.setError("Enter valid code");
                        editTextCode.requestFocus();
                        return;
                    }
                }

                //verifying the code entered manually
                verifyVerificationCode(code);
            }
        });
    }
    private void sendVerificationCode(String phone) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phone,
                60,
                TimeUnit.SECONDS,
                TaskExecutors.MAIN_THREAD,
                mCallbacks);
    }

    //the callback to detect the verification status
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {

            //Getting the code sent by SMS
            String code = phoneAuthCredential.getSmsCode();

            //sometime the code is not detected automatically
            //in this case the code will be null
            //so user has to manually enter the code
            if (code != null) {
                editTextCode.setText(code);
                //verifying the code
                verifyVerificationCode(code);
            }
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            hideProgress();
            Toast.makeText(VerifyPhone.this,"Invalid phone number Try again.!", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(VerifyPhone.this, Register.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
                hideProgress();
            mVerificationId = s;
        }
    };

    private void verifyVerificationCode(String code) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId, code);
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(VerifyPhone.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //verification successful we will start the profile activity
                           adduser();

                        } else {

                            //verification unsuccessful.. display an error message
                            String message = "Something is wrong, Please try again...";

                            Toast.makeText(getApplicationContext(),message,Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    public void adduser()
    {


        StringRequest postRequest = new StringRequest(Request.Method.POST, Urls.Register,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        hideProgress();
                        Intent intent = new Intent(VerifyPhone.this, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        hideProgress();

                        Toast.makeText(getApplicationContext(),"Something went wrong try again",Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        )
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("name", name);
                params.put("apikey", Urls.Apikey);
                params.put("email", email);
                params.put("password", password);
                params.put("phone", phone);
                return params;
            }
        };
        queue.add(postRequest);
        showProgress();
    }
    public void showProgress()
    {
        progresslayout.setVisibility(RelativeLayout.GONE);
        hud= KProgressHUD.create(VerifyPhone.this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("verifying Phone")
                .setCancellable(true)
                .setAnimationSpeed(2)
                .show();
    }
    public void hideProgress()
    {
        progresslayout.setVisibility(RelativeLayout.VISIBLE);
        hud.dismiss();
    }
}
