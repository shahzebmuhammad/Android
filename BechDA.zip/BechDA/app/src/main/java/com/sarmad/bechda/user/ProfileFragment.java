package com.sarmad.bechda.user;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.onesignal.OneSignal;
import com.sarmad.bechda.Api.Urls;
import com.sarmad.bechda.MainActivity;
import com.sarmad.bechda.R;
import com.sarmad.bechda.maps.MapsActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;


public class ProfileFragment extends Fragment {

    private View rootview;
    private KProgressHUD hud;
    private Context mcontext;
    private TextView updateProfile;
    private SharedPreferences.Editor editor;
    private RelativeLayout profileView;
    private RequestQueue queue;
    private String customerId;
    public String newsletter;
    private Switch aSwitch;
    private RelativeLayout locationtext;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootview = inflater.inflate(R.layout.activity_profile, container, false);
        mcontext = container.getContext();
        isUserLoggedIn();
        initializeLayouts();
        return rootview;
    }

    private void isUserLoggedIn() {
        SharedPreferences loginPref = mcontext.getSharedPreferences("loginPref", 0); // 0 - for private mode
        Boolean islogged = loginPref.getBoolean("status", false);
        if (islogged) {
        } else {
            Intent intent = new Intent(mcontext, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            Animatoo.animateSlideUp(mcontext);
        }
    }

    public void updateNotifications(final String status) {
        StringRequest postRequest = new StringRequest(Request.Method.POST, Urls.updateNotifications,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        hideProgress();
                        Log.i("resper", response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String responsestatus = jsonObject.getString("status");
                            if (responsestatus.equals("success")) {
                                String data = jsonObject.getString("data");
                                if (data.equals("1"))
                                {
                                    AlertDialog alertDialog = new AlertDialog.Builder(mcontext).create();
                                    alertDialog.setTitle("Subscribed");
                                    alertDialog.setMessage("You will now Receive Notifications");
                                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    dialog.dismiss();
                                                }
                                            });
                                    alertDialog.show();
                                    SharedPreferences.Editor editor = mcontext.getSharedPreferences("notification_pref", MODE_PRIVATE).edit();
                                    editor.putString("status", "1");
                                    editor.apply();
                                }
                                else
                                {
                                    AlertDialog alertDialog = new AlertDialog.Builder(mcontext).create();
                                    alertDialog.setTitle("Un Subscribed ");
                                    alertDialog.setMessage("You will no longer Receive Notifications");
                                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    dialog.dismiss();
                                                }
                                            });
                                    alertDialog.show();
                                    SharedPreferences.Editor editor = mcontext.getSharedPreferences("notification_pref", MODE_PRIVATE).edit();
                                    editor.putString("status", "0");
                                    editor.apply();
                                }

                            } else {
                                Toast.makeText(mcontext, response.toString(), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        hideProgress();
                        Toast.makeText(mcontext, "Something went wrong try again", Toast.LENGTH_LONG).show();
                        Log.d("Error.Response", error.toString());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("value", status);
                params.put("apikey", Urls.Apikey);
                params.put("id", customerId);
                return params;
            }
        };
        queue.add(postRequest);
        showProgress();
    }

    public void showProgress()
    {
        hud= KProgressHUD.create(mcontext)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Updating")
                .setCancellable(true)
                .setAnimationSpeed(2)
                .show();
    }
    public void hideProgress()
    {

        hud.dismiss();
    }
    public  void initializeLayouts()
    {        queue = Volley.newRequestQueue(mcontext);
        SharedPreferences loginPref = mcontext.getSharedPreferences("loginPref", 0); // 0 - for private mode
        final Boolean islogged = loginPref.getBoolean("status", false);
        String name = loginPref.getString("name", null);
        String email = loginPref.getString("email", null);
        String phone = loginPref.getString("phone", null);
        customerId = loginPref.getString("id", null);
        newsletter = loginPref.getString("newsletter", null);

        locationtext = rootview.findViewById(R.id.r8);

        TextView uname = rootview.findViewById(R.id.username);
        TextView uemail = rootview.findViewById(R.id.email);
        TextView uphone = rootview.findViewById(R.id.phone);
        updateProfile = rootview.findViewById(R.id.updateProfile);
        updateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mcontext, UpdateProfile.class);
                startActivity(intent);
            }
        });
        TextView changepassordtxt = rootview.findViewById(R.id.changepassordtxt);
        changepassordtxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getActivity(), ChangePassword.class);
                startActivity(intent);
            }
        });

        RelativeLayout Loggout = rootview.findViewById(R.id.r5);
        if (islogged) {
            uname.setText(name.toString());
            uemail.setText(email.toString());
            uphone.setText(phone.toString());
        }
        editor = loginPref.edit();

        Loggout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                editor.putString("name", "");
                editor.putString("email", "");
                editor.putString("phone", "");
                editor.putString("id", "");
                editor.putBoolean("status", false);
                editor.apply();

                Intent intent = new Intent(mcontext, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);

            }
        });
        profileView = (RelativeLayout) rootview.findViewById(R.id.profileView);
        profileView.bringToFront();
        aSwitch = rootview.findViewById(R.id.switch1);

        SharedPreferences Notif_prefs = mcontext.getSharedPreferences("notification_pref", MODE_PRIVATE);
        String stattus = Notif_prefs.getString("status", "");
        if (stattus=="1")
        {
            aSwitch.setChecked(true);
        }
        else
        {
            aSwitch.setChecked(false);
        }

        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    updateNotifications("1");
                    OneSignal.setSubscription(true);
                } else {
                    updateNotifications("0");
                    OneSignal.setSubscription(false);
                }
            }
        });

        locationtext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mcontext, MapsActivity.class);
                startActivity(intent);
            }
        });}

}